import { convictionModel } from "../model/conviction.model";
import { ConvictionFilters } from "../model/assetType.model";
import { Session } from "../model/session.model";

export interface AppState {
  convictions: { convictions: convictionModel[] };
  filters: { filters: ConvictionFilters };
  session:{session:Session}
}
