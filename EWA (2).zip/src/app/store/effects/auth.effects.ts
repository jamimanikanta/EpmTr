import { Injectable } from "../../../../node_modules/@angular/core";
import { Actions, Effect } from "../../../../node_modules/@ngrx/effects";
import { LoginService } from "../../login/login.service";
import * as authActions from "../actions/auth.actions";
import { map, switchMap, catchError } from "../../../../node_modules/rxjs/operators";
import { of } from "../../../../node_modules/rxjs/observable/of";

@Injectable()
export class AuthEffects{
    constructor(private actions$:Actions,
    private loginService:LoginService){}
    
    // @Effect() login = this.actions$.ofType(authActions.AuthActionTypes.Login).pipe(
    //     switchMap(action => {
    //       return this.loginService.login(action).pipe(
    //         map(data => new authActions.LoginSuccess(data)),
    //         catchError(error =>
    //           of(new authActions.LoginError(error))
    //         )
    //       );
    //     })
    //   );
}
