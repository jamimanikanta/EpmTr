import { Effect, Actions } from "@ngrx/effects";
import { Injectable, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import "rxjs/add/operator/map";
import "rxjs/add/operator/switchMap";
import "rxjs/add/operator/switchMap";
import "rxjs/add/operator/catch";
import { of } from "rxjs/observable/of";
import { switchMap, map, catchError } from "rxjs/operators";

import * as convictionsActions from "../actions/conviction.actions";
import * as convictionFilterActions from "../actions/filter.actions";
import { ConvictionService } from "../../convictions/conviction-details/conviction-details.service";
import { GetConvictionListSuccess } from "../actions/conviction.actions";

@Injectable()
export class ConvictionsEffects implements OnInit {
  constructor(
    private convictionsService: ConvictionService,
    private actions$: Actions<
      convictionsActions.ConvictionsActionTypes.GetConvictions
    >
  ) {}

  ngOnInit() {}

  @Effect()
  loadConvictions$ = this.actions$
    .ofType(convictionsActions.ConvictionsActionTypes.GetConvictions)
    .pipe(
      switchMap(() => {
        return this.convictionsService.getConvictionData().pipe(
          map(data => new convictionsActions.GetConvictionListSuccess(data)),
          catchError(error =>
            of(new convictionsActions.GetConvictionListError(error))
          )
        );
      })
    );

  @Effect()
  loadConvictionFilters$ = this.actions$
    .ofType(
      convictionFilterActions.ConvictionFilterActionTypes.GetConvictionFilter
    )
    .pipe(
      switchMap(() => {
        return this.convictionsService.getConvictionsFilterData().pipe(
          map(
            data => new convictionFilterActions.GetConvictionFilterSuccess(data)
          ),
          catchError(error =>
            of(new convictionFilterActions.GetConvictionFilterError(error))
          )
        );
      })
    );

  // @Effect()
  // loadConvictions$ = this.actions$
  //   .ofType(
  //     convictionsActions.ConvictionsActionTypes.GetConvictions
  //   )
  //   .pipe(
  //     switchMap(() => {
  //       let data = this.convictionsService.getConvictionData();
  //       let filters = this.convictionsService.getConvictionsFilterData()

  //       return Observable.forkJoin(data,filters)
  //           .map((data) => {
  //             new convictionsActions.GetConvictionListSuccess(data[0],data[1])
  //           })
  //       // return this.convictionsService.getConvictionsFilterData().pipe(
  //       //   map(
  //       //     data => new convictionFilterActions.GetConvictionFilterSuccess(data)
  //       //   ),
  //       //   catchError(error =>
  //       //     of(new convictionFilterActions.GetConvictionFilterError(error))
  //       //   )
  //       // );
  //     })
  //   );
}
