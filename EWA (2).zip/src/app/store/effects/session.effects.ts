import { Injectable } from "../../../../node_modules/@angular/core";
import { Actions, Effect } from "../../../../node_modules/@ngrx/effects";
import { LoginService } from "../../login/login.service";
import * as sessionActions from "../actions/session.actions";
import { map, switchMap, catchError } from "../../../../node_modules/rxjs/operators";
import { of } from "../../../../node_modules/rxjs/observable/of";

@Injectable()
export class SessionEffects {
    constructor(private actions$: Actions<sessionActions.SessionActionTypes.GetSession>,
        private loginService: LoginService) { }

    @Effect()
    GetSession$ = this.actions$
        .ofType(sessionActions.SessionActionTypes.GetSession)
        .pipe(
            switchMap((action:any) => {
                return this.loginService.login(action.credentials).pipe(
                    map(data => new sessionActions.GetSessionSuccess(data)),
                    catchError(error =>
                        of(new sessionActions.GetSessionError(error))
                    )
                );
            })
        );
}