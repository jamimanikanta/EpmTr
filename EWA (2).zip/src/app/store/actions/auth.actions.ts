import { Action } from "@ngrx/store";

export enum AuthActionTypes {
    Login = "[Login] get",
    LoginSuccess = "[Login] get success",
    LoginError = "[Login] get error",
}

export class Login implements Action {
    readonly type = AuthActionTypes.Login
    constructor(public credentials: any) { }
}

export class LoginSuccess implements Action {
    readonly type = AuthActionTypes.LoginSuccess
    constructor(public session: any) { }
}

export class LoginError implements Action {
    readonly type = AuthActionTypes.LoginError
    constructor(public error: any) { }
}

export type AuthActions = Login | LoginSuccess | LoginError