import { Action } from '@ngrx/store';
import { convictionModel } from '../../model/conviction.model';

export enum ConvictionsActionTypes {
    GetConvictions = '[Convictions] Get Convictions',
    GetConvictionsSuccess = '[Convictions] Success',
    GetConvictionsError = '[Convictions] Error'
}

export class GetConvictionList implements Action {
    readonly type =  ConvictionsActionTypes.GetConvictions
}

export class GetConvictionListSuccess implements Action {
    readonly type =  ConvictionsActionTypes.GetConvictionsSuccess
    constructor(public convictions:convictionModel[]){}
}


export class GetConvictionListError implements Action {
    readonly type =  ConvictionsActionTypes.GetConvictionsError
    constructor(public payload:any){}
}

export type ConvictionActions = GetConvictionList | GetConvictionListSuccess | GetConvictionListError;