import { Action } from "@ngrx/store";

export enum SessionActionTypes {
    GetSession = "[Session] get",
    GetSessionSuccess = "[Session] get success",
    GetSessionError = "[Session] get error",
}

export class GetSession implements Action {
    readonly type = SessionActionTypes.GetSession;
    constructor(public credentials:any){}
}

export class GetSessionSuccess implements Action {
    readonly type = SessionActionTypes.GetSessionSuccess
    constructor(public session: any) {
    }
}

export class GetSessionError implements Action {
    readonly type = SessionActionTypes.GetSessionError
    constructor(public error: any) { 
    }
}

export type SessionActions = GetSession | GetSessionSuccess | GetSessionError