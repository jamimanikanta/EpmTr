import { Action } from '@ngrx/store';
import { ConvictionFilters } from '../../model/assetType.model';

export enum ConvictionFilterActionTypes {
    GetConvictionFilter = '[ConvictionFilter] Get Conviction Filters',
    GetConvictionFilterSuccess = '[ConvictionFilter] Get Conviction Filters Success',
    GetConvictionFilterError = '[ConvictionFilter] Get Conviction Filters Error'
}

export class GetConvictionFilter implements Action {
    readonly type =  ConvictionFilterActionTypes.GetConvictionFilter
}

export class GetConvictionFilterSuccess implements Action {
    readonly type =  ConvictionFilterActionTypes.GetConvictionFilterSuccess
    constructor(public filters:ConvictionFilters){}
}


export class GetConvictionFilterError implements Action {
    readonly type =  ConvictionFilterActionTypes.GetConvictionFilterError
    constructor(public payload:any){}
}

export type ConvictionFilterActions = GetConvictionFilter | GetConvictionFilterSuccess | GetConvictionFilterError;