import { GetSession, SessionActionTypes, SessionActions } from "../actions/session.actions";
import { PersistanceService } from "../../shared/persistance.service";

export interface State {
  session: any
}

const initialState: State = {
  session: {}
}
export function SessionReducer(state = initialState, action: SessionActions): State {
  switch (action.type) {
    case (SessionActionTypes.GetSessionSuccess): {
      return Object.assign({}, state, {session:action.session})
    }
    case (SessionActionTypes.GetSessionError): {
      PersistanceService.isError = true;
    }
  }
  return state;
}