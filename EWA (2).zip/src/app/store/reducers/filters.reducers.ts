import {
  ConvictionFilterActions,
  ConvictionFilterActionTypes
} from "../actions/filter.actions";
import { AppState } from "../app.state";
import { ConvictionFilters } from "../../model/assetType.model";

export interface StateFilter {
  filters: ConvictionFilters;
}

const initialState: StateFilter = {
  filters: {
    assetTypes: [],
    prr: null,
    ltv: null,
    isRestricted: false
  }
};

export function ConvictionFilterReducer(
  state = initialState,
  action: ConvictionFilterActions
): StateFilter {
  switch (action.type) {
    case ConvictionFilterActionTypes.GetConvictionFilterSuccess: {
      return (state = {
        filters: action.filters
      });
    }
  }
  return state;
}
