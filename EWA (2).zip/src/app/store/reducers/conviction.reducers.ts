import { ConvictionActions, ConvictionsActionTypes, GetConvictionListSuccess } from '../actions/conviction.actions';
import { AppState } from '../app.state';
import { convictionModel } from '../../model/conviction.model';
import { ConvictionFilters } from '../../model/assetType.model';

export interface State {
    convictions: convictionModel[];
}

const initialState: State = {
    convictions:[]
}

export function ConvictionReducer(state = initialState, action: ConvictionActions) : State {
    switch(action.type){

        case (ConvictionsActionTypes.GetConvictionsSuccess) : {
            return state = {
                convictions: action.convictions
            }
        }
    }
    return state;
}
