import { TestBed, ComponentFixture, async, inject } from "@angular/core/testing";
import { LoginComponent } from "./login.component";
import { LoginService } from "./login.service";
import { PersistanceService } from "../shared/persistance.service";
import { Router, RouterModule } from "@angular/router";
import { NotificationService } from "../services/notification.service";
import { Store, StoreModule } from "@ngrx/store";
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { ToastrModule } from "ngx-toastr";
import { MatSnackBarModule } from "@angular/material";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ConvictionService } from "../convictions/conviction-details/conviction-details.service";
import { Observable } from "rxjs";
import { isError } from "util";

class MockRoute {
    navigate = jasmine.createSpy("navigate");
}

class MockStore {    
    select() { return Observable.of({session: "" })};
    dispatch() { };
}

class MockNotificationService {
    warning() {}
}

describe("Component: Login", () => {

    let component: LoginComponent;
    let fixture: ComponentFixture<LoginComponent>;
    const mockStore = new MockStore();
    const mockNotificationService = new MockNotificationService();

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [LoginComponent],
            imports: [FormsModule, HttpClientModule, RouterModule, ToastrModule.forRoot(), MatSnackBarModule, StoreModule.forRoot({}), BrowserAnimationsModule],
            providers: [
                LoginService,
                PersistanceService,
                { provide: Router, useClass: MockRoute },
                { provide: NotificationService, useValue: mockNotificationService},
                { provide: Store, useValue: mockStore },
                ConvictionService
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(LoginComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });


    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    it('should be login with valid credentails', () => {
        const loginDetails = { Username: 'admin', Password: 'admin@' };
        PersistanceService.isError = true;
        const spy = spyOn(mockStore, 'dispatch');
        spyOn(mockNotificationService, 'warning');        

        component.login();

        expect(spy).toHaveBeenCalled();
        expect(mockNotificationService.warning).toHaveBeenCalledWith('Invalid credentials. Please try again or contact Prowess.');
        PersistanceService.isError = false;
    });

});