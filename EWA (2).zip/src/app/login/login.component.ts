import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { LoginService } from './login.service';
import { PersistanceService } from '../shared/persistance.service';
import { Router } from '@angular/router';
import { LoaderClass } from '../shared/loading';
import { NotificationService } from '../services/notification.service';
import { AppConstants } from '../shared/app.constants';
import { environment } from '../../environments/environment';
import { Store, State } from '@ngrx/store';
import { AppState } from '../store/app.state';
import * as convictionActions from '../store/actions/conviction.actions';
import * as convictionFilterActions from '../store/actions/filter.actions';
import * as sessionActions from '../store/actions/session.actions';
import { ConvictionService } from '../convictions/conviction-details/conviction-details.service';

@Component({
    selector: 'login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    loginDetails = { "ApiKey": environment.API_KEY, "Culture": "en-US", "Username": "", "Password": "" }
    errorMsg: string;
    showSpinner: boolean = LoaderClass.loading;
    loginStatus: boolean = false;
    @Output() loggedIn = new EventEmitter();

    constructor(private loginService: LoginService,
        private persistanceService: PersistanceService,
        private router: Router,
        private notification: NotificationService,
        private store: Store<AppState>,
        private convictionService: ConvictionService) {
    }

    ngOnInit() {
    }

    login() {
        this.store.dispatch(new convictionActions.GetConvictionList());
        this.store.dispatch(new convictionFilterActions.GetConvictionFilter());
        this.showSpinner = true;
        this.store.dispatch(new sessionActions.GetSession({
            Username: this.loginDetails.Username,
            Password: this.loginDetails.Password
        }));

        const session$ = this.store.select(s => s.session);
        session$.subscribe((data) => {
            if (PersistanceService.isError) {
                this.showSpinner = false;
                this.notification.warning('Invalid credentials. Please try again or contact Prowess.');
                this.errorMsg = 'Invalid credentials. Please try again or contact Prowess.';
            }
            if (Object.keys(data.session).length != 0) {
                PersistanceService.isError = false;
                this.showSpinner = false;
                this.persistanceService.eventNotify(true);
                this.router.navigateByUrl("/convictions")
            }
        });
        // const session1$ = Observable.of(this.store.select(s => s.session.session).map(s => <Session>s));
        // session1$.last().subscribe((data) => {
        //     if (data) {
        //         console.log("last subscribe");
        //         console.log(data);
        //         this.showSpinner = false;
        //         this.persistanceService.eventNotify(true);
        //         this.router.navigateByUrl("/convictions")
        //     }
        //     else {
        //         this.showSpinner = false;
        //         this.notification.warning('Invalid credentials. Please try again or contact Prowess.');
        //         this.errorMsg = 'Invalid credentials. Please try again or contact Prowess.';
        //     }
        // });




        // const session$ = this.store.select(s => s.session.session).map(data => <Session>(data)).subscribe(
        //     (data) => {
        //         if (data.token) {
        //             console.log("in if");
        //             console.log(data);
        //             this.showSpinner = false;
        //             this.persistanceService.eventNotify(true);
        //             this.router.navigateByUrl("/convictions")
        //         }
        //         else {
        //             console.log("in else");
        //             console.log(data);
        //             this.showSpinner = false;
        //             this.notification.warning('Invalid credentials. Please try again or contact Prowess.');
        //             this.errorMsg = 'Invalid credentials. Please try again or contact Prowess.';
        //         }
        //     }
        // );
        // this.store.select(s => s.session).map().subscribe((data) => {
        //     this.loginStatus = Object.keys(data.session).length === 0 ? false : true;
        // });
        // this.loginService.login(this.loginDetails)
        //     .subscribe(data => {
        //         debugger;
        //         if(data) {
        //             this.showSpinner = false;
        //             this.persistanceService.eventNotify(true);
        //             this.router.navigateByUrl("/convictions")
        //         }
        //         else{
        //             this.showSpinner = false;
        //             this.notification.warning('Invalid credentials. Please try again or contact Prowess.');
        //             this.errorMsg = 'Invalid credentials. Please try again or contact Prowess.';
        //         }
        //     },
        //         error => {
        //             LoaderClass.loading = false;
        //             console.log(error);
        //             }
        // );
    }
}