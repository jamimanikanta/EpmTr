import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { PersistanceService } from '../shared/persistance.service';
import { FactoryOrValue } from 'rxjs/interfaces';
import { AppConstants } from '../shared/app.constants';
import { environment } from '../../environments/environment';
import { UserInformationComponent } from '../userinformation/user-information.component';
import { Store } from '@ngrx/store';
import { AppState } from '../store/app.state';

@Injectable()
export class LoginService {
    baseUrl: string = environment.baseUrl;

    constructor(private http: HttpClient,
        private persistance: PersistanceService,
        private store: Store<AppState>) { }

    login(details): Observable<any> {
        //ToDo:  http call for authentication
        const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
        return this.http.post("http://ec2-54-213-65-232.us-west-2.compute.amazonaws.com/api/api/admin",details,{headers:headers});
        //return this.http.get("assets/data/features.json");
        // if (details.Username === "admin" && details.Password === "admin@123") {
        //     return this.http.get("assets/data/features.json");
        // }
        // if(details.Username === "admin" && details.Password === "admin@123") {
        //     this.http.get("assets/data/features.json").subscribe(
        //         (response)=>{
        //             console.log(response);
        //             this.persistance.set("features",response);
        //         }
        //     );
        //     this.persistance.set('user', JSON.stringify(details.Username))
        //     return new Observable<true>();
        // }
        // else {
        //     return new Observable<false>();
        // }

        // return this.http.post(this.baseUrl + "json/reply/BusinessEntity_Login", details)
        //                 .map(data => {
        //                     if((<IUserDetails>data).IsSuccess == true){
        //                         this.persistance.set('user', JSON.stringify(data))
        //                         return true;
        //                     }
        //                     else{
        //                         return false;
        //                     }
        //                 });

    }
}

export interface IUserDetails {
    "ShaSessionGuid": string,
    "ShaSessionGuidString": string,
    "FirstName": string,
    "LastName": string,
    "CompLevel": string,
    "EmailAddress": string,
    "Status": string,
    "ClassId": string,
    "BeeNumber": number,
    "BeeNumberAssignedTo": number,
    "AssignedToName": string,
    "Culture": string,
    "RegistrationInprogress": false,
    "RegistrationMasterOrderId": number,
    "RegistrationPoeShoppingCartsId": number,
    "IsSuccess": boolean,
    "ResponseCode": number,
    "LocalizedResponseText": string,
    "PhotoURL": string,
    "LevelName": string,
    "CountryCode": string
}