import { TestBed } from "@angular/core/testing";
import { LoginService } from "./login.service";
import { HttpClient, HttpClientModule } from "@angular/common/http";
import { PersistanceService } from "../shared/persistance.service";
import { RouterModule, Router } from "@angular/router";
import { of } from "rxjs/observable/of";
import { StoreModule, Store } from "@ngrx/store";
import { ConvictionReducer } from "../store/reducers/conviction.reducers";

class mockRoute {
    navigate = jasmine.createSpy("navigate");
}

describe("LoginService", () => {
    let service: LoginService;
    
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientModule, RouterModule, StoreModule.forRoot({
                convictions: ConvictionReducer
              })],
            providers: [LoginService, HttpClient, PersistanceService, { provide: Router, useClass: mockRoute }, Store]
        }).compileComponents();

        service = TestBed.get(LoginService);
    });

    it('should create', () => {
        expect(service).toBeTruthy();
    });

    it('should login with valid username and password', () => {
        const details = { Username: 'admin', Password: 'admin@' };
        const mockAuthenticated = of(true);
        const spy = spyOn(service, 'login').and.returnValue(mockAuthenticated);

        service.login(details).subscribe((data) => {
            expect(data).toBeTruthy();
        });
        expect(spy).toHaveBeenCalled();
    });

    it('should be failed with invalid username or password', () => {
        const details = { Username: '', Password: '' };
        const mockAuthenticated = of(false);
        spyOn(service, 'login').and.returnValue(mockAuthenticated);

        service.login(details).subscribe((data) => {
            expect(data).toBeFalsy();
        });
    });
});