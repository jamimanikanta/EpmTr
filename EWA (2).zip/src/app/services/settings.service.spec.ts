import { TestBed, inject } from '@angular/core/testing';
import { SettingsService } from './settings.service';

describe('SettingsService', () => {    
  beforeEach(() => {
    TestBed.configureTestingModule({      
      providers: [SettingsService]
    });
  });

  it('should be created', inject([SettingsService], (service: SettingsService) => {
    expect(service).toBeTruthy();
  }));

  it('should return sideBar Image index', inject([SettingsService], (service: SettingsService) => {
    service.sidebarImageIndex = 10;

    expect(service.getSidebarImageIndex()).toEqual(10);    
}));

it('should set sideBar Image index', inject([SettingsService], (service: SettingsService) => {
    spyOn(service.sidebarImageIndexUpdate, 'emit');
    service.setSidebarImageIndex(4);

    expect(service.sidebarImageIndexUpdate.emit).toHaveBeenCalledWith(4);
}));

it('should return sideBar Filter', inject([SettingsService], (service: SettingsService) => {
    service.sidebarFilter = "#CCC";

    expect(service.getSidebarFilter()).toEqual("#CCC");    
}));

it('should set sideBar Filter', inject([SettingsService], (service: SettingsService) => {
    spyOn(service.sidebarFilterUpdate, 'emit');
    service.setSidebarFilter("#EEE");

    expect(service.sidebarFilterUpdate.emit).toHaveBeenCalledWith("#EEE");
}));

it('should return sideBar Color', inject([SettingsService], (service: SettingsService) => {
    service.sidebarColor = "#F00C0C";

    expect(service.getSidebarColor()).toEqual("#F00C0C");    
}));

it('should set sideBar Filter', inject([SettingsService], (service: SettingsService) => {
    spyOn(service.sidebarColorUpdate, 'emit');
    service.setSidebarColor("#F00C0C");

    expect(service.sidebarColorUpdate.emit).toHaveBeenCalledWith("#F00C0C");
}));
});
