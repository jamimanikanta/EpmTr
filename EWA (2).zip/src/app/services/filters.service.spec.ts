import { TestBed, inject } from '@angular/core/testing';

import { FiltersService } from './filters.service';
import { HttpClientModule } from "@angular/common/http";
import { of } from 'rxjs/observable/of';

describe('FiltersService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[ HttpClientModule ],
      providers: [FiltersService]
    });
  });

  it('should be created', inject([FiltersService], (service: FiltersService) => {
    expect(service).toBeTruthy();
  }));

  it('should get Assests', inject([FiltersService], (service: FiltersService) => {    

    let assets = [{ "id":1, "name":"Equity",
                  "subTypes":[{ "id":1, "name":"Global Growth" }, { "id":2, "name":"Asia Growth" }, { "id":3, "name":"Asia Dividend" }, { "id":4, "name":"Trade Convictions" }]},
                  { "id":2, "name":"Funds",
                  "subTypes":[ { "id":1, "name":"Multi Assets" }, { "id":2, "name":"Equities" }, { "id":3, "name":"Bonds" }, { "id":4, "name":"Alternatives" }]},
                  { "id":3, "name":"Bonds", "subTypes":[ { "id":1, "name":"Asia IG" }, { "id":2, "name":"Asia HY" }, { "id":3, "name":"DM" }, { "id":4, "name":"EM" }, { "id":5, "name":"LC"}]
                 }];
    
    const mockAssets = of(assets);
    const spy = spyOn(service, 'getJSON').and.returnValue(mockAssets);

    service.getJSON().subscribe((data) => {
      expect(data).toEqual(assets);
    });
    expect(service.getJSON).toHaveBeenCalled();
}));
});
