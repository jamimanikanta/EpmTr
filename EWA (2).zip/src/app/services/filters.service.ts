import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs/Observable';

@Injectable()
export class FiltersService {

  constructor(private http: HttpClient) { }
  public getJSON(): Observable<any> {
    return this.http.get("./assets/data/assetTypes.json")
  }
}
