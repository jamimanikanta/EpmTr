import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from "@angular/router";
import { AuthGaurd } from './authguard.service';
import { PersistanceService } from "../shared/persistance.service";
import { NotificationService } from './notification.service';
import { ToastrModule } from 'ngx-toastr';
import { MatSnackBarModule } from '@angular/material';
import { StoreModule, Store } from '@ngrx/store';
import { ConvictionReducer } from '../store/reducers/conviction.reducers';

describe('AuthGaurdService', () => {  
  beforeEach(() => {
    TestBed.configureTestingModule({
        imports: [RouterModule, RouterTestingModule, ToastrModule.forRoot(), MatSnackBarModule, StoreModule.forRoot({
          convictions: ConvictionReducer
        })],
      providers: [AuthGaurd, PersistanceService, NotificationService, Store]
    });
  });

  it('should be created', inject([AuthGaurd], (service: AuthGaurd) => {
    expect(service).toBeTruthy();
  }));

  it('should call canActivate', inject([AuthGaurd, PersistanceService], (service: AuthGaurd, persistanceService: PersistanceService) => {
    let userDetailsMock = {"ShaSessionGuid": "",
    "ShaSessionGuidString": "123",
    "FirstName": "Jasmine",
    "LastName": "Karma",
    "CompLevel": "",
    "EmailAddress":"",
    "Status": "",
    "ClassId": "",
    "BeeNumber": 5,
    "BeeNumberAssignedTo": 0,
    "AssignedToName": "",
    "Culture": "",
    "RegistrationInprogress": false,
    "RegistrationMasterOrderId": 0,
    "RegistrationPoeShoppingCartsId": 0,
    "IsSuccess": true,
    "ResponseCode": 0,
    "LocalizedResponseText": "",
    "PhotoURL": "",
    "LevelName": "",
    "CountryCode": ""};
    persistanceService.IsAuthenticated = true;
    let spy = spyOn(persistanceService, "get").and.returnValue(userDetailsMock);

    expect(service.canActivate(null, null)).toBeTruthy();
    expect(spy).toHaveBeenCalled();
    expect(persistanceService.IsAuthenticated).toBeTruthy();
}));
});
