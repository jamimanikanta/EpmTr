export enum Features{
    Convictions=1,
    Themes,
    Macros
}

export enum ConvictionsSubFeatures{
    AssetTypes=1,
    PRR,
    LTV,
    IncludeRestricted
}