import { Component, OnInit } from '@angular/core';
import { Router, ActivationStart, NavigationStart } from '@angular/router';
import { Subscription } from 'rxjs';
import { PersistanceService } from './shared/persistance.service';
import { IUserDetails } from './login/login.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  showSpinner:boolean = false;
  title = 'app';
  IsAuth:boolean;
  private messageSubscription: Subscription;
  userName:string;
  persistanceService:PersistanceService;

  constructor(private router:Router, 
              persistanceService:PersistanceService,
              private translate: TranslateService){

                this.translate.addLangs(['en', 'fr']);
                this.translate.setDefaultLang('en');

                //const browserLang = translate.getBrowserLang();
                //translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');

                this.persistanceService = persistanceService;
              }

  ngOnInit(): void {
    this.messageSubscription = this.persistanceService.message.subscribe(data => {
      //validate if the storage has user info
      if(this.persistanceService.isAuthenticated) { data = true; }
      this.IsAuth = data;
      this.userName = this.persistanceService.userDisplayName();
    });
  }

  login() {
    this.router.navigateByUrl("/login");
  }

  logout() {
    this.persistanceService.clear();
    this.IsAuth = false;
    this.router.navigateByUrl("/login");
  }

  loadAddress(){
    this.router.navigateByUrl("/address");
  }

  profile(){
    this.router.navigateByUrl("/beget");
  }

  banking(){
    this.router.navigateByUrl("/banking");
  }

  loggedIn(data:any) {
    alert("Clicked logged in");
  }

  incentvie(){
    this.router.navigateByUrl("/incentive");
  }

  bookingCalendar() {
    this.router.navigateByUrl("events/calendar");
  }

  eventDetails(){
    this.router.navigateByUrl("events/details");
  }

  googleLogin() {
    // google login provider
  }

}
