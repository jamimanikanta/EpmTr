import { Component, Input } from '@angular/core';
import { PersistanceService } from '../shared/persistance.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector:'user-information',
    templateUrl:'./user-information.component.html',
    styleUrls:['./user-information.component.css']
})
export class UserInformationComponent {
    @Input() userName:string;
    selectedLanguage:string ="en";
    persistanceService:PersistanceService;
    
    constructor(private _persistanceService:PersistanceService,
                private translate:TranslateService){
        this.persistanceService = _persistanceService;
    }

    logOut() {
        this.persistanceService.clear();
    }

    changeLan(lan:string) {
        this.translate.setDefaultLang(lan);
        this.selectedLanguage = lan;
    }
}