import { BrowserModule } from "@angular/platform-browser";
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { Router, RouterModule, Routes } from "@angular/router";
import { FlexLayoutModule } from "@angular/flex-layout";
import { PolymerModule } from '@codebakery/origami';
import {
  HttpClientModule,
  HTTP_INTERCEPTORS,
  HttpClient
} from "@angular/common/http";
import { LoadingModule } from "ngx-loading";
import { ToastrModule } from "ngx-toastr";
import {
  NgProgressModule,
  NgProgressBrowserXhr,
  NgProgressInterceptor
} from "ngx-progressbar";
import { BrowserXhr } from "@angular/http";
import { AppComponent } from "./app.component";
import { MaterialModule } from "./material.module";
import { LoginComponent } from "./login/login.component";
import { FigurecardComponent } from "./shared/figurecard/figurecard.component";
import { ImagecardComponent } from "./shared/imagecard/imagecard.component";
import { NavbarComponent } from "./shared/navbar/navbar.component";
import { MsgIconBtnComponent } from "./shared/msgiconbtn/msgiconbtn.component";
import { SidebarComponent } from "./sidebar/sidebar.component";
import { SettingsService } from "./services/settings.service";
import { LoginService } from "./login/login.service";
import { PersistanceService } from "./shared/persistance.service";
import { AuthGaurd } from "./services/authguard.service";
import { NotificationService } from "./services/notification.service";
import { StoreFeatureModule, StoreModule, ActionReducer, MetaReducer } from "@ngrx/store";
import { localStorageSync } from 'ngrx-store-localstorage';
import { EffectsModule } from "@ngrx/effects";
import { AppRoutingModule } from "./app-routing.module";
import { ThemifyModule } from "ngx-icons";
import { MatExpansionModule } from "@angular/material/expansion";
import { WidgetLoader } from "./shared/widgetLoader/widgetLoad-component";
import { CalendarComponent } from "./sidebar/calendar/calendar-component";
import { HeaderNavigationComponent } from "./header-navigation/header-navigation.component";
import { UserInformationComponent } from "./userinformation/user-information.component";
import { MyFilterPipe } from "./shared/filter.pipe";
//Translation Modules
import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

//ngx-scroll
import { NgxAutoScrollModule } from "ngx-auto-scroll";
import { ConvictionReducer } from "./store/reducers/conviction.reducers";
import { ConvictionsEffects } from "./store/effects/conviction.effects";
import { ConvictionService } from './convictions/conviction-details/conviction-details.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { IonRangeSliderModule } from "ng2-ion-range-slider";
import { MatDialogModule, MatCheckboxModule } from "@angular/material";
import { AssetTypesComponent } from "./convictions/filters/asset-types/asset-types.component";
import { PrrDialogComponent } from "./convictions/filters/prr-dialog/prr-dialog.component";
import { LtvDialogComponent } from "./convictions/filters/ltv-dialog/ltv-dialog.component";
import { ConvictionFilterReducer } from "./store/reducers/filters.reducers";
import { SessionReducer } from "./store/reducers/session.reducers";
import { SessionEffects } from "./store/effects/session.effects";
import { AuthEffects } from "./store/effects/auth.effects";
import { FeatureTogglingComponent } from './admin/feature-toggling/feature-toggling.component';
import { FeatureTogglingService } from "./admin/feature-toggling/feature-toggling.service";


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, "./assets/i18n/", ".json");
}

export function localStorageSyncReducer(reducer: ActionReducer<any>): ActionReducer<any> {
  return localStorageSync({keys: ['convictions', 'filters', 'session'], rehydrate: true})(reducer);
}
const metaReducers: Array<MetaReducer<any, any>> = [localStorageSyncReducer];

@NgModule({
  schemas:[CUSTOM_ELEMENTS_SCHEMA],
  declarations: [
    AppComponent,
    FigurecardComponent,
    ImagecardComponent,
    UserInformationComponent,
    NavbarComponent,
    HeaderNavigationComponent,
    MsgIconBtnComponent,
    LoginComponent,
    SidebarComponent,
    WidgetLoader,
    CalendarComponent,
    PrrDialogComponent,
    LtvDialogComponent,
    FeatureTogglingComponent
  ],
  imports: [
    BrowserModule,
    IonRangeSliderModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    MatDialogModule,
    MatCheckboxModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    AppRoutingModule,
    FlexLayoutModule,
    MaterialModule,
    MatExpansionModule,
    LoadingModule,
    NgProgressModule,
    ThemifyModule,
    NgxAutoScrollModule,
    ToastrModule.forRoot(),
    StoreModule.forRoot({
      convictions: ConvictionReducer,
      filters: ConvictionFilterReducer,
      session: SessionReducer
    }, {
      metaReducers
    }),
    EffectsModule.forRoot([
      ConvictionsEffects,
      SessionEffects,
      AuthEffects
    ])
  ],
  providers: [
    SettingsService,
    LoginService,
    PersistanceService,
    NotificationService,
    AuthGaurd,
    ConvictionService,
    FeatureTogglingService,
    { provide: HTTP_INTERCEPTORS, useClass: NgProgressInterceptor, multi: true }
  ],
  bootstrap: [AppComponent],
  entryComponents:[
    PrrDialogComponent,
    LtvDialogComponent
  ]
  
})
export class AppModule { }
