import { Component } from '@angular/core';
import { PersistanceService } from '../shared/persistance.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';


@Component({
    selector:'header-navigation',
    templateUrl:'./header-navigation.component.html',
    styleUrls:['./header-navigation.component.css']
})
export class HeaderNavigationComponent {

    languages = [
        {value: 'en', text: 'English'},
        {value: 'fr', text: 'French'},
      ];

    constructor(private persistanceService:PersistanceService,
                private router:Router,
            private translate:TranslateService){}

    logOut() {
        this.persistanceService.clear();
    }

    changeLanguage(event:any){
        this.translate.use(event.value);
    }
}