export interface Session {
    token: string;
    featuresModel: Feature[];
    defaultPage: string;
}


export interface Feature {
    featureId: number;
    featureName: string;
    isEnabled: boolean;
    subFeatures: SubFeature[];
}

export interface SubFeature {
    subFeatureId: number,
    subFeatureName: string,
    isEnabled: boolean
}