export class AssetType {
    id: number;
    name: string;
    value: boolean = false;
    indeterminate: boolean = false;
    subTypes: AssetSubType[]
}

export class AssetSubType {
    id: number;
    name: string;
    value: boolean = false;
}

export class PRR {
    min: number;
    max: number;
    includeWithoutPrr: boolean;
    indclude:boolean;
}

export class LTV {
    min: number;
    max: number;
    includeWithoutLtv: boolean;
    include:boolean;
}


export class ConvictionFilters {
    assetTypes: AssetType[];
    prr: PRR;
    ltv: LTV;
    isRestricted: boolean;
}
