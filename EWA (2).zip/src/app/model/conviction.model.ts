export interface convictionModel {
    convictionName:string;
    identifier:string;
    convictionId:number;
    prr:number;
    ltv:number;
    inception:Date;
    api:string;
    convictionBuckets:any[];
    isRestricted:boolean;
}