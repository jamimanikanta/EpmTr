export interface FileModel {
    fileProcessId: number;
    clientId: number;
    filePath: string;
    uploadedOn: Date,
    processedOn: Date,
    statusId: number,
    fileName: string,
    fileContent: string
}