import { Injectable } from '@angular/core'
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { environment } from '../../../environments/environment';
import { filter } from 'rxjs/operator/filter';
import { FilteredData } from '../filters/filter.model';
import { urls } from '../../constants/url.constants';
import { AssetType, ConvictionFilters } from '../../model/assetType.model';
import { convictionModel } from '../../model/conviction.model';

@Injectable()
export class ConvictionService {
    public convictionFilters: ConvictionFilters;
    constructor(private http: HttpClient) { }

    getDataFromService(): Observable<any> {
        return this.http.get(environment.baseUrl + "values").map(data => <any>data);
    }

    getTickerData(ticker): Observable<any> {
        return this.http.get(environment.stockApiUrl.replace("{0}", ticker))
            .map(data => <any>data);
    }

    getConvictionData(filterData: FilteredData = null): Observable<convictionModel[]> {
        const headers = new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8');
        return this.http.post(urls.convictions, filterData, { headers: headers }).map(data => <any>data);
    }

    getConvictionsFilterData(): Observable<ConvictionFilters> {
        return this.http.get(urls.filters).map(data => <ConvictionFilters>data);
    }
}