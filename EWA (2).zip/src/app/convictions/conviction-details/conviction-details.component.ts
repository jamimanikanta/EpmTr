import { Component, OnInit } from '@angular/core';
import { ConvictionService } from './conviction-details.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-conviction-details',
  templateUrl: './conviction-details.component.html',
  styleUrls: ['./conviction-details.component.css']
})
export class ConvictionDetailsComponent implements OnInit {
  data:any;
  companyName:string;
  symbol:string;
  peratio:any;
  ytd:any;

  constructor(private convictionService: ConvictionService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    const param = this.route.snapshot.params;

    this.convictionService.getTickerData(param.id).subscribe(data => {
      this.data = data;
      this.companyName = this.data.companyName;
      this.symbol = this.data.symbol;
      this.peratio = this.data.peRatio;
      this.ytd = +(this.data.ytdChange*100).toFixed(1);
    });
  }
}
