import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { ConvictionDetailsComponent } from './conviction-details.component';
import { MatIconModule, MatCardModule } from "@angular/material";
import { ConvictionService } from './conviction-details.service';
import {HttpClientModule} from "@angular/common/http";
import { RouterModule, ActivatedRoute} from "@angular/router";

describe('ConvictionDetailsComponent', () => {
  let component: ConvictionDetailsComponent;
  let fixture: ComponentFixture<ConvictionDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConvictionDetailsComponent ],
      imports:[MatIconModule, MatCardModule, HttpClientModule, RouterModule],
      providers:[ConvictionService, {provide: ActivatedRoute}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConvictionDetailsComponent);
    component = fixture.componentInstance;
    //fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit', inject([ConvictionService, ActivatedRoute], (convictionServiceMock: ConvictionService, routeMock: ActivatedRoute) => {        
    
  }));
});
