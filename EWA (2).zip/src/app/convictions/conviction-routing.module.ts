import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConvictionsListComponent } from './convictions-list/convictions-list.component';
import { ConvictionDetailsComponent } from './conviction-details/conviction-details.component';

const routes: Routes = [
  { path:'', redirectTo:'convictions', pathMatch:'full'},
  { path:'convictions', component:ConvictionsListComponent },
  { path:'conviction-details/:id', component:ConvictionDetailsComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConvictionRoutingModule { }
