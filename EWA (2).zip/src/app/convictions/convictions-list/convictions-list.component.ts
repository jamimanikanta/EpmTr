import { Component, OnInit, ViewEncapsulation, Inject } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";
import { coerceNumberProperty } from "@angular/cdk/coercion";
import {
  MatDialog,
  MatDialogConfig,
  MatChipInputEvent
} from "@angular/material";
import { Router } from "@angular/router";
import { ConvictionFilterPipe } from "../../shared/conviction.filter";
import { ConvictionService } from "../conviction-details/conviction-details.service";
import { Store } from "@ngrx/store";
import { AppState } from "../../store/app.state";
import { Observable } from "rxjs";
import * as convictionActions from "../../store/actions/conviction.actions";
import * as convictionFilterActions from "../../store/actions/filter.actions";
import { convictionModel } from "../../model/conviction.model";
import { FormControl } from "@angular/forms";
import {
  AssetType,
  ConvictionFilters,
  PRR,
  AssetSubType
} from "../../model/assetType.model";
import { AssetTypesComponent } from "../filters/asset-types/asset-types.component";
import { FilteredData } from "../filters/filter.model";
import { PrrDialogComponent } from "../filters/prr-dialog/prr-dialog.component";
import { LtvDialogComponent } from "../filters/ltv-dialog/ltv-dialog.component";
import { OrderByPipe } from "../../shared/sort.filter";
import { PersistanceService } from "../../shared/persistance.service";
import { SubFeature } from "../../model/session.model";
import { Features } from "../../app.constant";

//Polymer component
import '@polymer/paper-checkbox/paper-checkbox';
import '@polymer/paper-input/paper-input';
import '@polymer/paper-button/paper-button';
import { FileUploadComponent } from "../../file-upload/file-upload.component";

@Component({
  selector: "app-convictions-list",
  templateUrl: "./convictions-list.component.html",
  styleUrls: ["./convictions-list.component.css"],
  encapsulation: ViewEncapsulation.None
})
export class ConvictionsListComponent implements OnInit {
  autoTicks = false;
  disabled: boolean = false;
  invert = false;
  max = 8;
  min = 1;
  showTicks = true;
  step = 1;
  thumbLabel = true;
  value = 0;
  vertical = false;
  isIncludedRestricted = false;

  trg: number = 1125;
  searchText: string;
  sortBy: string[] = [
    "Latest Inception",
    "Oldest Inception",
    "Best Value (Short-term)",
    "Best Value (Long-term)",
    "Lowest Risk"
  ];

  convictions$: Observable<convictionModel[]>;

  convictionFilters$: Observable<ConvictionFilters>;
  convictionFilters: ConvictionFilters; // stores all filters
  filteredData: FilteredData; // stores filtered data
  filterdBuckets: AssetSubType[] = [];
  sortCriteria: string = "Latest Inception";
  sortOrder: boolean = false;

  convictionFeatures: SubFeature[] ;


  constructor(
    private translate: TranslateService,
    private router: Router,
    private store: Store<AppState>,
    private convictionService: ConvictionService,
    private dialog: MatDialog,
    private persistanceService: PersistanceService
  ) {
  
  
  }

  ngOnInit() {


    this.convictions$ = this.store.select(
      state => state.convictions.convictions
    );

    // this.convictions$ = this.store.select(
    //   state => state.convictions.convictions
    // );



    this.convictionFilters$ = this.store.select(state =>
      state.filters.filters
    );


    this.filteredData = new FilteredData();
    this.filteredData.bucketIds = [];
    this.filteredData.prr = { min: 1, max: 7, includeWithoutPrr: false, indclude: false };
    this.filteredData.ltv = { min: 0, max: 80, includeWithoutLtv: false, include: false };
    this.filteredData.includeRestricted = false;

    this.persistanceService.getFeature(Features.Convictions).subscribe(
      (subFeatures)=>{this.convictionFeatures=subFeatures;}
    );
  }

  get tickInterval(): number | "auto" {
    return this.showTicks ? (this.autoTicks ? "auto" : this._tickInterval) : 0;
  }
  set tickInterval(value) {
    this._tickInterval = coerceNumberProperty(value);
  }

  private _tickInterval = 1;

  convictionDetails(ticker) {
    this.router.navigateByUrl("/convictions/conviction-details/" + ticker);
  }

  openAssetFiltersDialog(): void {
    let assets: ConvictionFilters;
    this.convictionFilters$.subscribe(data => {
      assets = data;
    })
    const dialogRef = this.dialog.open(AssetTypesComponent, {
      width: "800px",
      data: { assetTypes: assets.assetTypes }
    });

    dialogRef.afterClosed().subscribe(buckets => {
      if (buckets) {
        this.filterdBuckets = buckets;
        this.filteredData.bucketIds = buckets.map(b => b.id);
        this.getConvictions();
      }
    });
  }

  getConvictions() {
    this.convictions$ = this.convictionService.getConvictionData(
      this.filteredData
    );
  }
  prrdialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.width = "500px";
    dialogConfig.data = {
      prr: this.filteredData.prr
    };
    const metdialog = this.dialog.open(PrrDialogComponent, dialogConfig);
    metdialog.afterClosed().subscribe(prrValues => {
      if (prrValues) {
        this.filteredData.prr = prrValues;
        this.getConvictions();
      }
    });
  }

  ltvdialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.width = "500px";
    dialogConfig.data = {
      ltv: this.filteredData.ltv
    };
    const metdialog = this.dialog.open(LtvDialogComponent, dialogConfig);
    metdialog.afterClosed().subscribe(ltvValues => {
      if (ltvValues) {
        this.filteredData.ltv = ltvValues;
        this.getConvictions();
      }
    });
  }

  includedRestricted() {
    this.isIncludedRestricted = !this.isIncludedRestricted;
    this.filteredData.includeRestricted = this.isIncludedRestricted;
    this.getConvictions();
  }

  removable = true;

  unFilter(bucketId: number): void {
    //get the index of the removed bucket
    const index = this.filteredData.bucketIds.indexOf(bucketId);
    //If the element is found remove from filteredData and filteredBuckets
    if (index >= 0) {
      this.filteredData.bucketIds.splice(index, 1);
      this.filterdBuckets.splice(index, 1);
    }

    this.convictionFilters$.subscribe((assetType) => {
      assetType.assetTypes.forEach(assetType => {
        //If all the buckets in an Asset type are selected set the asset types state to indeterminate
        if (
          assetType.subTypes.filter(st => st.value == true).length ==
          assetType.subTypes.length
        ) {
          assetType.indeterminate = true;
        }
        //If the selected asset type has only one bucket remove intermediate state of asset type
        else if (
          assetType.subTypes.filter(st => st.value == true).length == 1 &&
          assetType.subTypes.filter(st => st.id == bucketId).length > 0
        ) {
          assetType.indeterminate = false;
        }
        //Uncheck the value of the removed bucket
        assetType.subTypes
          .filter(st => st.id == bucketId)
          .map(st => (st.value = false));
      })
    });

    this.getConvictions();
  }
  fileUpload() {

    const dialogRef = this.dialog.open(FileUploadComponent, {
      width: "800px",
      data: {}
    });

    dialogRef.afterClosed().subscribe(buckets => {
      if (buckets) {

      }
    });


  }

  sortData(sort: any) {
    this.sortCriteria === "Oldest Inception"
      ? (this.sortOrder = true)
      : (this.sortOrder = false);
  }
}
