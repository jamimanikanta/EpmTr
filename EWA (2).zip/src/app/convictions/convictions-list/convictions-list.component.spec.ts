import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ConvictionsListComponent } from './convictions-list.component';
import { MatCardModule, MatFormFieldModule, MatSelectModule, MatIconModule, MatDialogModule, MatInputModule, MatChipsModule, MatButtonModule } from "@angular/material";
import { TranslateModule, TranslateService, TranslateLoader } from '@ngx-translate/core';
import { FormsModule } from "@angular/forms";
import { ConvictionFilterPipe } from '../../shared/conviction.filter';
import { TooltipModule } from 'ngx-tooltip';
import { HttpLoaderFactory } from "../../app.module";
import { HttpClientModule, HttpClient } from "@angular/common/http";
import { StoreModule, Store } from "@ngrx/store";
import { ConvictionReducer } from "../../store/reducers/conviction.reducers";
import { ConvictionService } from '../conviction-details/conviction-details.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OrderByPipe } from '../../shared/sort.filter';

import { PolymerModule } from '@codebakery/origami';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import '@polymer/paper-input/paper-input';
import '@polymer/paper-button/paper-button';
import { PersistanceService } from '../../shared/persistance.service';
import { SessionReducer } from '../../store/reducers/session.reducers';

describe('ConvictionsListComponent', () => {
  let component: ConvictionsListComponent;
  let fixture: ComponentFixture<ConvictionsListComponent>;
  let persistanceServiceMock: any;
  persistanceServiceMock = {
    getFeature: () => { }
};

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConvictionsListComponent, ConvictionFilterPipe, OrderByPipe  ],
      imports:[PolymerModule, HttpClientModule, RouterTestingModule, MatCardModule, MatFormFieldModule, MatIconModule, MatSelectModule, MatDialogModule, MatInputModule,
        MatChipsModule, MatButtonModule, TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [HttpClient]
        }
      }), StoreModule.forRoot({
        session: SessionReducer
      }), FormsModule, TooltipModule, BrowserAnimationsModule],
      providers:[TranslateService, Store, ConvictionService, { provide: PersistanceService, useValue: persistanceServiceMock}],
      schemas:[CUSTOM_ELEMENTS_SCHEMA]                 
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConvictionsListComponent);
    component = fixture.componentInstance;
    //fixture.detectChanges();
  });

  it('should create', () => {    
    expect(component).toBeTruthy();
  });
});