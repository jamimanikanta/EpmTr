import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrrDialogComponent } from './prr-dialog.component';
import { IonRangeSliderModule } from "ng2-ion-range-slider";
import { MatCheckboxModule, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA, MatIconModule } from "@angular/material";
import { FormsModule } from '@angular/forms';
import { PRR } from '../../../model/assetType.model';
import { StoreModule, Store } from "@ngrx/store";
import { ConvictionReducer } from "../../../store/reducers/conviction.reducers";

describe('PrrDialogComponent', () => {
  let component: PrrDialogComponent;
  let fixture: ComponentFixture<PrrDialogComponent>;
  let dialogMock: any;
  dialogMock = {
    close: () => { }
};
  let prrMock = new PRR();
      prrMock.min = 1;
      prrMock.max = 7;   

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrrDialogComponent ],
      imports:[ IonRangeSliderModule, MatCheckboxModule, MatDialogModule, MatIconModule, FormsModule,StoreModule.forRoot({
        convictions: ConvictionReducer
      }) ],
      providers:[ { provide: MatDialogRef, useValue: dialogMock }, { provide: MAT_DIALOG_DATA, useValue: { prr: prrMock } }, Store ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrrDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should equal prr range', () => {
    component.prr = new PRR();
    let eventMock = {from: 2, to: 4}
    component.myOnChange(eventMock);

    expect(component.prr.min).toEqual(2);
    expect(component.prr.max).toEqual(4);
  });

  it('should apply Filter', () => {
    component.applyFilter();    
    expect(component.prr.min).toEqual(1);
    expect(component.prr.max).toEqual(7);
  });
});
