import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MatSlider, MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { coerceNumberProperty } from "@angular/cdk/coercion";
import { PRR } from '../../../model/assetType.model';
import { Store } from '@ngrx/store';
import { AppState } from '../../../store/app.state';

@Component({
  selector: "app-prr-dialog",
  templateUrl: "./prr-dialog.component.html",
  styleUrls: ["./prr-dialog.component.css"]
})
export class PrrDialogComponent implements OnInit {
  min = 1;
  max = 7;
  step = 1;
  grid_num = (this.max - 1);

  prr: PRR;
  checked: "true";

  private _tickInterval = 1;

  constructor(
    private store: Store<AppState>, 
    private dialogRef: MatDialogRef<PrrDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data) {
    this.prr = this.data.prr;
  }

  myOnChange(event) {
    this.prr.min = event.from;
    this.prr.max = event.to;
  }

  ngOnInit() { }

  applyFilter() {
    //this.store.filter(state=>state.filters.filters.prr=this.prr);
    // this.store.(state => 
    //   state.filters.filters
    // );
    this.dialogRef.close(this.prr);
  }

  clearFilters() {
    this.prr = new PRR();
    this.dialogRef.close(this.prr);
  }

  closeDialog(){

  }
}
