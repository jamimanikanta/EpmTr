import { PRR, LTV } from "../../model/assetType.model";

export class FilteredData {
    bucketIds: number[];
    prr: PRR;
    ltv: LTV;
    includeRestricted:boolean;
}

export interface RangeValue {
    min: number;
    max: number;
}
