import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ConvictionsListComponent } from '../../convictions-list/convictions-list.component';
import { AssetType, AssetSubType, ConvictionFilters } from '../../../model/assetType.model';

@Component({
  selector: 'app-asset-types',
  templateUrl: './asset-types.component.html',
  styleUrls: ['./asset-types.component.css']
})
export class AssetTypesComponent implements OnInit {

  filterData: any;
  constructor(
    public dialogRef: MatDialogRef<ConvictionsListComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  ngOnInit() {
  }

  checkSubTypes(id: any) {
    this.data.assetTypes.filter(t => t.id === id).map(t => t.subTypes.forEach(st => st.value = t.value));
  }

  checkParent(assetType: AssetType) {
    const checkCount = assetType.subTypes.filter(st => st.value === true).length;
    this.data.assetTypes.filter(t => t.id === assetType.id).forEach(t => { t.indeterminate = false; });
    if (checkCount === 0) {
      this.data.assetTypes.filter(t => t.id === assetType.id).forEach(t => { t.value = false; });
    } else if (checkCount === assetType.subTypes.length) {
      this.data.assetTypes.filter(t => t.id === assetType.id).forEach(t => { t.value = true; });
    } else {
      this.data.assetTypes.filter(t => t.id === assetType.id).forEach(t => { t.value = false; });
      this.data.assetTypes.filter(t => t.id === assetType.id).forEach(t => { t.indeterminate = true; });
    }
  }

  applyFilters() {
    const buckets: AssetSubType[] = [];
    this.data.assetTypes.forEach(type => {
      return type.subTypes.filter(st => st.value === true)
        .map(st => buckets.push(st));
    });
    this.dialogRef.close(buckets);
  }

  //Clears all selected filters
  clearFilters(){
    this.data.assetTypes.forEach(t=>{
        t.indeterminate=false;
        t.value=false;
        t.subTypes.forEach(st=>st.value=false);
      });
//    this.dialogRef.close([]);
  }

  //Closes the dialog
  closeDialog(){
    //reset filters
    //this.convictionService.convictionFilters.assetTypes=this.tempData;
    //close the dialog
    this.dialogRef.close([]);
  }
}
