import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetTypesComponent } from './asset-types.component';
import { MatCheckboxModule } from "@angular/material";
import { FormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatIconModule } from '../../../../../node_modules/@angular/material';
import { AssetType } from '../../../model/assetType.model';

describe('AssetTypesComponent', () => {
  let component: AssetTypesComponent;
  let fixture: ComponentFixture<AssetTypesComponent>;
  let dialogMock: any;
  dialogMock = {
    close: () => { }
};

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetTypesComponent ],
      imports:[ MatCheckboxModule, MatIconModule, FormsModule ],
      providers:[ { provide: MatDialogRef, useValue: dialogMock }, { provide: MAT_DIALOG_DATA } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetTypesComponent);
    component = fixture.componentInstance;
    //fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check subTypes', () => {
    component.data = new AssetType();
    component.data.assetTypes = [];    
    component.data = {assetTypes : [{name: "Equity", id: 1, value: true,
                                     subTypes: [ {name: "Global Growth", id: "1", value: false, subTypes: []},
                                                 {name: "Asia Growth", id: "2", value: false, subTypes: []},
                                                 {name: "Asia Dividend", id: "3", value: false, subTypes: []},
                                                 {name: "Trade Convictions", id: "4", value: false, subTypes: []}],
                                      indeterminate: undefined},
                                    {name: "Funds", id: 2, value: false,
                                    subTypes: [ {name: "Multi Assets", id: "5", value: false, subTypes: []},
                                                {name: "Equities", id: "6", value: false, subTypes: []},
                                                {name: "Bonds", id: "7", value: false, subTypes: []},
                                                {name: "Alternatives", id: "8", value: false, subTypes: []}],
                                    indeterminate: undefined},
                                    {name: "Bonds", id: 3, value: false,
                                    subTypes: [ {name: "Asia IG", id: "9", value: false, subTypes: []},                                    
                                                {name: "Asia HY", id: "10", value: false, subTypes: []},                                    
                                                {name: "DM", id: "11", value: false, subTypes: []},                                    
                                                {name: "EM", id: "12", value: false, subTypes: []},                                    
                                                {name: "LC", id: "13", value: false, subTypes: []}],
                                    indeterminate: undefined}] };
    component.checkSubTypes(1);    
    expect(component.data.assetTypes.filter(t => t.id === 1).every(t => t.subTypes.every(st => st.value === true))).toBeTruthy();
    expect(component.data.assetTypes.filter(t => t.id === 2).every(t => t.subTypes.every(st => st.value === false))).toBeTruthy();
    expect(component.data.assetTypes.filter(t => t.id === 3).every(t => t.subTypes.every(st => st.value === true))).toBeFalsy();
  });

  it('should uncheck Parent checkbox', () => {
    component.data = AssetType;
    component.data.assetTypes = [];
    component.data = {assetTypes : [{name: "Equity", id: 1, value: false,
                                     subTypes: [ {name: "Global Growth", id: "1", value: false, subTypes: []},
                                                 {name: "Asia Growth", id: "2", value: false, subTypes: []},
                                                 {name: "Asia Dividend", id: "3", value: false, subTypes: []},
                                                 {name: "Trade Convictions", id: "4", value: false, subTypes: []}],
                                      indeterminate: true },
                                    {name: "Funds", id: 2, value: false,
                                    subTypes: [ {name: "Multi Assets", id: "5", value: false, subTypes: []},
                                                {name: "Equities", id: "6", value: false, subTypes: []},
                                                {name: "Bonds", id: "7", value: false, subTypes: []},
                                                {name: "Alternatives", id: "8", value: false, subTypes: []}],
                                    indeterminate: undefined},
                                    {name: "Bonds", id: 3, value: false,
                                    subTypes: [ {name: "Asia IG", id: "9", value: false, subTypes: []},                                    
                                                {name: "Asia HY", id: "10", value: false, subTypes: []},                                    
                                                {name: "DM", id: "11", value: false, subTypes: []},                                    
                                                {name: "EM", id: "12", value: false, subTypes: []},                                    
                                                {name: "LC", id: "13", value: false, subTypes: []}],
                                    indeterminate: undefined}] };
    component.checkParent(component.data.assetTypes[0]);  
    expect(component.data.assetTypes.filter(t => t.id === 1).every(t => t.indeterminate === false && t.value === false)).toBeTruthy();
  });

  it('should check Parent checkbox', () => {

    component.data = {assetTypes : [{name: "Equity", id: 1, value: false,
                                     subTypes: [ {name: "Global Growth", id: "1", value: true, subTypes: []},
                                                 {name: "Asia Growth", id: "2", value: true, subTypes: []},
                                                 {name: "Asia Dividend", id: "3", value: true, subTypes: []},
                                                 {name: "Trade Convictions", id: "4", value: true, subTypes: []}],
                                      indeterminate: false },
                                    {name: "Funds", id: 2, value: false,
                                    subTypes: [ {name: "Multi Assets", id: "5", value: false, subTypes: []},
                                                {name: "Equities", id: "6", value: false, subTypes: []},
                                                {name: "Bonds", id: "7", value: false, subTypes: []},
                                                {name: "Alternatives", id: "8", value: false, subTypes: []}],
                                    indeterminate: undefined},
                                    {name: "Bonds", id: 3, value: false,
                                    subTypes: [ {name: "Asia IG", id: "9", value: false, subTypes: []},                                    
                                                {name: "Asia HY", id: "10", value: false, subTypes: []},                                    
                                                {name: "DM", id: "11", value: false, subTypes: []},                                    
                                                {name: "EM", id: "12", value: false, subTypes: []},                                    
                                                {name: "LC", id: "13", value: false, subTypes: []}],
                                    indeterminate: undefined}] };

      component.checkParent(component.data.assetTypes[0]);
      expect(component.data.assetTypes.filter(t => t.id === 1).every(t => t.value === true)).toBeTruthy();
  });

  it('should be intermediate and uncheck Parent checkbox', () => {

      component.data = {assetTypes : [{name: "Equity", id: 1, value: true,
                                     subTypes: [ {name: "Global Growth", id: "1", value: false, subTypes: []},
                                                 {name: "Asia Growth", id: "2", value: true, subTypes: []},
                                                 {name: "Asia Dividend", id: "3", value: false, subTypes: []},
                                                 {name: "Trade Convictions", id: "4", value: true, subTypes: []}],
                                      indeterminate: false },
                                    {name: "Funds", id: 2, value: false,
                                    subTypes: [ {name: "Multi Assets", id: "5", value: false, subTypes: []},
                                                {name: "Equities", id: "6", value: false, subTypes: []},
                                                {name: "Bonds", id: "7", value: false, subTypes: []},
                                                {name: "Alternatives", id: "8", value: false, subTypes: []}],
                                    indeterminate: undefined},
                                    {name: "Bonds", id: 3, value: false,
                                    subTypes: [ {name: "Asia IG", id: "9", value: false, subTypes: []},                                    
                                                {name: "Asia HY", id: "10", value: false, subTypes: []},                                    
                                                {name: "DM", id: "11", value: false, subTypes: []},                                    
                                                {name: "EM", id: "12", value: false, subTypes: []},                                    
                                                {name: "LC", id: "13", value: false, subTypes: []}],
                                    indeterminate: undefined}] };

      component.checkParent(component.data.assetTypes[0]);
      expect(component.data.assetTypes.filter(t => t.id === 1).every(t => t.value === false && t.indeterminate === true)).toBeTruthy();
  });

  it('should apply Filter', () => {    
    component.data = AssetType;
    component.data.assetTypes = [];    
    
    component.applyFilters();    
  });

  it('should apply Filter', () => {    
    component.data = AssetType;
    component.data.assetTypes = [];
    component.data = {assetTypes : [{name: "Equity", id: 1, value: false,
                                     subTypes: [ {name: "Global Growth", id: "1", value: false, subTypes: []},
                                                 {name: "Asia Growth", id: "2", value: true, subTypes: []},
                                                 {name: "Asia Dividend", id: "3", value: false, subTypes: []},
                                                 {name: "Trade Convictions", id: "4", value: true, subTypes: []}],
                                      indeterminate: undefined},
                                    {name: "Funds", id: 2, value: true,
                                    subTypes: [ {name: "Multi Assets", id: "5", value: true, subTypes: []},
                                                {name: "Equities", id: "6", value: false, subTypes: []},
                                                {name: "Bonds", id: "7", value: false, subTypes: []},
                                                {name: "Alternatives", id: "8", value: false, subTypes: []}],
                                    indeterminate: undefined},
                                    {name: "Bonds", id: 3, value: true,
                                    subTypes: [ {name: "Asia IG", id: "9", value: false, subTypes: []},                                    
                                                {name: "Asia HY", id: "10", value: true, subTypes: []},                                    
                                                {name: "DM", id: "11", value: false, subTypes: []},                                    
                                                {name: "EM", id: "12", value: false, subTypes: []},                                    
                                                {name: "LC", id: "13", value: true, subTypes: []}],
                                    indeterminate: undefined}] };
    
    component.clearFilters();
    expect(component.data.assetTypes.every(t => t.value === false && t.indeterminate === false && t.subTypes.every(st => st.value === false))).toBeTruthy();    
  });
});
