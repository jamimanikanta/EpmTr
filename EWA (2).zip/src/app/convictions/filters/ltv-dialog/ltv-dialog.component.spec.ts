import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LtvDialogComponent } from './ltv-dialog.component';
import { IonRangeSliderModule } from "ng2-ion-range-slider";
import { MatCheckboxModule, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { FormsModule } from '@angular/forms';
import { LTV } from '../../../model/assetType.model';


describe('LtvDialogComponent', () => {
  let component: LtvDialogComponent;
  let fixture: ComponentFixture<LtvDialogComponent>;
  let dialogMock: any;
  dialogMock = {
    close: () => { }
};
  let ltvMock = new LTV();
  ltvMock.min = 0;
  ltvMock.max = 80;

  beforeEach(async(() => {
      TestBed.configureTestingModule({
      declarations: [ LtvDialogComponent ],
      imports:[ IonRangeSliderModule, MatCheckboxModule, MatDialogModule, FormsModule ],
      providers:[ { provide: MatDialogRef, useValue: dialogMock }, { provide: MAT_DIALOG_DATA, useValue: { ltv: ltvMock } } ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LtvDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should equal ltv range', () => {    
    let eventMock = {from: 10, to: 20}
    component.myOnChange(eventMock);

    expect(component.ltv.min).toEqual(10);
    expect(component.ltv.max).toEqual(20);
  });

  it('should apply Filter', () => {
    component.applyFilter();    
    expect(component.ltv.min).toEqual(10);
    expect(component.ltv.max).toEqual(20);    
  });  
});
