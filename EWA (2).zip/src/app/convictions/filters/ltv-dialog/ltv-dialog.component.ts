import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { LTV } from '../../../model/assetType.model';

@Component({
  selector: 'app-ltv-dialog',
  templateUrl: './ltv-dialog.component.html',
  styleUrls: ['./ltv-dialog.component.css']
})
export class LtvDialogComponent implements OnInit {
  min = 0;
  max = 80;
  grid_num = 4;

  description: string;
  private _tickInterval = 1;

  ltv: LTV;

  constructor(
    private dialogRef: MatDialogRef<LtvDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data) {
      this.ltv = this.data.ltv;
    }

  myOnChange(event) {
    this.ltv.min = event.from;
    this.ltv.max = event.to;
  }

  ngOnInit() { }

  applyFilter() {
    this.dialogRef.close(this.ltv);
  }

  clearFilters() {
    this.ltv = new LTV();
    this.dialogRef.close(this.ltv);
  }
}
