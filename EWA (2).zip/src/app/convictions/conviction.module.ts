import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PolymerModule } from '@codebakery/origami';
import { ConvictionRoutingModule } from "./conviction-routing.module";
import { ConvictionsListComponent } from "./convictions-list/convictions-list.component";
import { ConvictionDetailsComponent } from "./conviction-details/conviction-details.component";
//Material
import {
  MatExpansionModule,
  MatCardModule,
  MatTabsModule,
  MatFormFieldModule,
  MatSelectModule,
  MatDatepickerModule,
  MatCheckboxModule,
  MatInputModule,
  MatSnackBarModule,
  MatDialogModule,
  MatButtonModule,
  MatSliderModule,
  MatIconModule,
  MatChipsModule
} from "@angular/material";
import { TranslateModule } from "@ngx-translate/core";
import { ConvictionService } from "./conviction-details/conviction-details.service";
import { MyFilterPipe } from "../shared/filter.pipe";
import { ConvictionFilterPipe } from "../shared/conviction.filter";
import { TooltipModule } from "ngx-tooltip";
import { StoreModule } from "@ngrx/store";
import { ConvictionReducer } from "../store/reducers/conviction.reducers";
import { AssetTypesComponent } from "./filters/asset-types/asset-types.component";
import { PrrDialogComponent } from "./filters/prr-dialog/prr-dialog.component";
import { LtvDialogComponent } from "./filters/ltv-dialog/ltv-dialog.component";
import { SortPipe, OrderByPipe } from '../shared/sort.filter';
import {FileUploadComponent} from '../file-upload/file-upload.component'
import {FileUploadService} from '../file-upload/fileUpload.service'


@NgModule({
  schemas:[CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ConvictionRoutingModule,
    MatExpansionModule,
    MatChipsModule,
    MatCardModule,
    MatButtonModule,
    MatTabsModule,
    MatFormFieldModule,
    MatSliderModule,
    MatIconModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatInputModule,
    MatSnackBarModule,
    MatDialogModule,
    MatSelectModule,
    TranslateModule.forChild(),
    TooltipModule,
    PolymerModule.forRoot()
  ],
  declarations: [
    ConvictionsListComponent,
    ConvictionDetailsComponent,
    ConvictionFilterPipe,
    SortPipe,
    OrderByPipe,
    MyFilterPipe,
    AssetTypesComponent,
    FileUploadComponent
  ],
  providers: [ConvictionService,FileUploadService],
  entryComponents: [AssetTypesComponent,FileUploadComponent]
})
export class ConvictionModule {}
