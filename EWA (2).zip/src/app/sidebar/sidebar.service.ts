import { Injectable, Type } from '@angular/core';
import { CalendarComponent } from './calendar/calendar-component';


@Injectable()
export class SidebarService {
  widgets: { [id: string]: Type<{}> } = {
    'app-sidebar-widget-1': CalendarComponent,
    'app-sidebar-widget-2': CalendarComponent,
    'app-sidebar-widget-3': CalendarComponent
  };
}
