import { Component, OnInit } from '@angular/core';

@Component({
    selector:'sidebar-calendar',
    template:`<div>Calendar</div>`,
    styleUrls:[]
})
export class CalendarComponent implements OnInit {

    ngOnInit(){}
}