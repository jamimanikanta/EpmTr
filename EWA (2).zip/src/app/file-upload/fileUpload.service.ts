import { Injectable } from '@angular/core'
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { urls } from '../constants/url.constants';

@Injectable()
export class FileUploadService {
    constructor(private http: HttpClient) { }

    upload(file:any) {
        const headers = new HttpHeaders({
            'Content-Type': 'application/json; charset=utf-8'
        });
        return this.http.post(urls.fileUpload, file, { headers: headers });
    }
}