import { TestBed, inject, async } from "@angular/core/testing";
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientModule, HttpClient } from "@angular/common/http";
import { FileUploadService } from "./fileUpload.service";
import { urls } from '../constants/url.constants';
describe('FileUploadService', () => {
    let service: FileUploadService;
    beforeEach(()=> {
        TestBed.configureTestingModule({
            imports: [HttpClientModule, HttpClientTestingModule ],
            providers: [FileUploadService, HttpClient]
        });

        service = TestBed.get(FileUploadService);
    });

    afterEach(inject([HttpTestingController], (backend: HttpTestingController) => {
        backend.verify();
    }));


    it('should create', () => {
        expect(service).toBeTruthy();
    });


    it(`should emit 'true' for 200 Ok`, async(inject([FileUploadService, HttpTestingController],
        (service: FileUploadService, backend: HttpTestingController) => {
            let mockFile = [{
                fileName: 'Sample',
                fileContent: 'asdsadsdd'
            }]
          service.upload(mockFile).subscribe((next) => {
            expect(next).toBeNull();
          });
    
          backend.expectOne(urls.fileUpload).flush(null, { status: 200, statusText: 'Ok' });
      })));
});