import { Component, OnInit, Inject} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import '@vaadin/vaadin-upload/vaadin-upload.js';
import { FileUploadService } from '../file-upload/fileUpload.service'
import { FileModel } from '../model/FileModel.model';



@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<FileUploadComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _fileUploadService: FileUploadService) { }
  fileArray: File = null;

  fileObj: FileModel = {
    fileProcessId: null,
    clientId: null,
    filePath: '',
    uploadedOn: null,
    processedOn: null,
    statusId: null,
    fileName: '',
    fileContent: ''
  };

  ngOnInit() {
  }

  uploadFiles = (event) => {
    let reader = new FileReader();
    let file = event.detail.file;
    
    reader.readAsDataURL(file);
    reader.onloadend = () => {
      var files = [];
      this.fileObj['fileContent'] = reader.result.split(',')[1];
      this.fileObj.fileName = file.name;

      files.push(this.fileObj);

      this._fileUploadService.upload(files).subscribe(response => {
      });
    }
  }
}
