import { TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from "@angular/router";
import { PersistanceService } from './persistance.service';
import { IUserDetails } from '../login/login.service';
import { StoreModule, Store } from "@ngrx/store";
import { ConvictionReducer } from '../store/reducers/conviction.reducers';
import { Observable } from 'rxjs';
import { AppState } from '../store/app.state';

describe('PersistanceService', () => {
    let spy : any;
    let userDetailsMock = {"ShaSessionGuid": "",
      "ShaSessionGuidString": "123",
      "FirstName": "Jasmine",
      "LastName": "Karma",
      "CompLevel": "",
      "EmailAddress":"",
      "Status": "",
      "ClassId": "",
      "BeeNumber": 5,
      "BeeNumberAssignedTo": 0,
      "AssignedToName": "",
      "Culture": "",
      "RegistrationInprogress": false,
      "RegistrationMasterOrderId": 0,
      "RegistrationPoeShoppingCartsId": 0,
      "IsSuccess": true,
      "ResponseCode": 0,
      "LocalizedResponseText": "",
      "PhotoURL": "",
      "LevelName": "",
      "CountryCode": ""};
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[ RouterModule, RouterTestingModule, StoreModule.forRoot({
        convictions: ConvictionReducer
      }) ],
      providers: [PersistanceService, Store]
    });
  });

  it('should be created', inject([PersistanceService], (service: PersistanceService) => {
    expect(service).toBeTruthy();
  }));

  it('should get stored Item', inject([PersistanceService], (service: PersistanceService) => {
    spy = spyOn(localStorage, "getItem").and.returnValue(JSON.stringify(userDetailsMock));
    expect(service.get("")).toEqual(userDetailsMock as IUserDetails);
    expect(spy).toHaveBeenCalled();
}));

it('should set the Item', inject([PersistanceService], (service: PersistanceService) => {    
    service.IsAuthenticated = false;
    spy = spyOn(localStorage, "setItem");

    service.set("", "");
    expect(spy).toHaveBeenCalled();
    expect(service.IsAuthenticated).toBeTruthy();
}));

it('should clear Items', inject([PersistanceService], (service: PersistanceService) => {    
    service.IsAuthenticated = true;    

    service.clear();    
    expect(service.IsAuthenticated).toBeFalsy();
}));

it('should return User Name', inject([PersistanceService], (service: PersistanceService) => {        
    spy = spyOn(service, "get").and.returnValue(JSON.stringify(userDetailsMock));    

    expect(service.userDisplayName()).toEqual(userDetailsMock.LastName + ", " + userDetailsMock.FirstName);
    expect(spy).toHaveBeenCalled();
}));

it('should authenticate User', inject([PersistanceService, Store], (service: PersistanceService, store: Store<AppState>) => {            
    spy = spyOn(store, "select").and.returnValue(Observable.of({session: {token: ""}}));

    expect(service.isAuthenticated()).toBeTruthy();
    expect(spy).toHaveBeenCalled();
}));
});
