import { ConvictionFilterPipe } from "./conviction.filter";

describe('ConvictionFilterPipe', () => {
    let pipe = new ConvictionFilterPipe();
    let items: any = [
        {
            convictionName: 'asset',
            identifier: 'asset',
        }
    ];
    let searchTerm = '';

    it('should filter items with empty search and no status value', () => {
        expect(pipe.transform(items, searchTerm)).toEqual(items);
    });

    it('should filter items with search value', () => {
        searchTerm = 'asset';
        expect(pipe.transform(items, searchTerm).length).toBeGreaterThanOrEqual(2);
    });
});
