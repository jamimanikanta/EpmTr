import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: "ConvictionFilter",
    pure: false
})
export class ConvictionFilterPipe implements PipeTransform {
    transform(items: any[], searchTerm: string = ''): any {
        let temp: any[] = [];
        let tempSearch: any[] = [];

        if (searchTerm && searchTerm.length > 0) {
            //ensure this object is filled
            if (temp.length == 0) { temp = items; }

            if (temp) {
                temp.forEach((item: any) => {
                    if (item.convictionName.toLowerCase().includes(searchTerm.toLowerCase())) {
                        tempSearch.push(item);
                    }

                    if (item.identifier.toLowerCase().includes(searchTerm.toLowerCase())) {
                        tempSearch.push(item);
                    }

                    //finally push to return object
                    temp = tempSearch;
                });
            }
            return temp;
        }

        //If search text is empty return all items
        return items;
    }
}