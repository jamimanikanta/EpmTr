import { Pipe } from "@angular/core";
import { convictionModel } from "../model/conviction.model";

@Pipe({ name: "sortBy" })
export class SortPipe {
  transform(array: convictionModel[], args: string): convictionModel[] {
    array.sort((a: convictionModel, b: convictionModel) => {
      if (a[args] < b[args]) {
        return -1;
      } else if (a[args] > b[args]) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }
}

@Pipe({
  name: "orderBy"
})
export class OrderByPipe {
  transform(array: convictionModel[], orderBy: string, asc = true) {
    if (!orderBy || orderBy.trim() == "") {
      return array;
    }

if(array){
    //ascending
    if (asc) {
      return Array.from(array).sort((item1: any, item2: any) => {
        return this.orderByComparator(item1[orderBy], item2[orderBy]);
      });
    } else {
      //not asc
      return Array.from(array).sort((item1: any, item2: any) => {
        return this.orderByComparator(item2[orderBy], item1[orderBy]);
      });
    }
    }
  }

  orderByComparator(a: any, b: any): number {
    if (
      isNaN(parseFloat(a)) ||
      !isFinite(a) ||
      (isNaN(parseFloat(b)) || !isFinite(b))
    ) {
      
      //Isn't a number so lowercase the string to properly compare
      if ( a && typeof(a) == "string" && a.toLowerCase() < b && typeof(b) == "string" && b.toLowerCase()) return -1;
      if ( a && typeof(a) == "string" && a.toLowerCase() > b && typeof(b) == "string" && b.toLowerCase()) return 1;
    } else {
      //Parse strings as numbers to compare properly
      if (parseFloat(a) < parseFloat(b)) return -1;
      if (parseFloat(a) > parseFloat(b)) return 1;
    }
    return 0; //equal each other
  }
}
