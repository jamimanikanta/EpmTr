import { MyFilterPipe } from "./filter.pipe";

describe('EventFilterPipe', () => {
    let pipe = new MyFilterPipe();
    let items: any[] = [
        {
            EventId: 1,
            Title: 'asset',
            EventStartDate: '25-08-2017',
            EventEndDate: '25-08-2018',
            TimeZone: '',
            Address: [],
            Guests: [],
            MasterOrderId: 10,
            EventStatus: 'success',
            ExternalReferenceId: 'refx123'
        }
    ];
    let searchTerm = '';
    let status = [];

    it('should filter items with empty search and no status value', () => {
        expect(pipe.transform(items, searchTerm, status)).toEqual(items);
    });

    it('should filter items with search and status value', () => {
        searchTerm = 'asset';
        status.push('success');

        expect(pipe.transform(items, searchTerm, status)).toEqual(items);

        status.length = 0;

        expect(pipe.transform(items, searchTerm, status)).toEqual(items);
    });
});
