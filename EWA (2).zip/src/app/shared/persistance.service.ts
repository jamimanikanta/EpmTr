import { Injectable, EventEmitter, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';
import { IUserDetails } from '../login/login.service';
import { Router } from '@angular/router';
import { Store } from '../../../node_modules/@ngrx/store';
import { AppState } from '../store/app.state';
import { Session, Feature, SubFeature } from '../model/session.model';
import { Features } from '../app.constant';
import { of } from 'rxjs/observable/of';

@Injectable()
export class PersistanceService implements OnInit {
  public static isError:boolean = false;
  
  public IsAuthenticated: boolean = false;
  public userName: string = "";
  public avatar: string = "";
  public showSpinner: boolean = false;
  data = new EventEmitter(); //Event Delegation
  private messageNotify: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public message = this.messageNotify.asObservable();

  public statusList: any[] = ['Open', 'Closed', 'In Process', 'Cancelled']
  public eventTypes: any[] = ['Party Order',
    'Auto Close Event Party',
    'Meetings',
    'Webinar',
    'Party with Rebates',
    'Private Appointment',
    'Show',
    'Team Event']

  constructor(private router: Router, private store: Store<AppState>) { }

  ngOnInit() {
    //check if already authenticated

  }

  //returns feature data from store
  getFeature(featureNumber: Features): Observable<SubFeature[]> {
    var subFeatures: any;
    this.store.select(s => s.session.session).map(data => <Session>(data)).subscribe(
      (session) => { 
        subFeatures= session.featuresModel.find(f=>f.featureId==featureNumber).subFeatures;
       }
    );
    return of(subFeatures);
  }

  isAuthenticated(): boolean {
    var session: any=null;
    this.store.select(s=>s.session).subscribe(
      (data)=>{session=data;}
    );
    if (session.session.hasOwnProperty('token')) {
      return true;
    }
    return false;
  }

  userDisplayName(): any {
    var auth = JSON.parse(this.get('user')) as IUserDetails;
    if (auth != null && auth.FirstName != "") {
      return auth.LastName + ", " + auth.FirstName;
    }
  }

  set(key: string, data: any): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
      //set Authenticated to true
      this.IsAuthenticated = true;
    } catch (e) {
      console.error('Error saving to localStorage', e);
    }
  }

  get(key: string) {
    try {
      return JSON.parse(localStorage.getItem(key));
    } catch (e) {
      console.error('Error getting data from localStorage', e);
      return null;
    }
  }

  clear() {
    localStorage.clear();
    this.IsAuthenticated = false;
    this.router.navigateByUrl("login");
  }

  eventNotify(value: boolean) {
    this.messageNotify.next(value);
  }

}