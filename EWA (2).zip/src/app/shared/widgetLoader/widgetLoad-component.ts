import { SidebarService } from '../../sidebar/sidebar.service';
import { Component, 
        OnInit, 
        ComponentFactoryResolver,
        Compiler,
        Input,
        OnDestroy,
        ViewChild,
        ViewContainerRef,
        ComponentRef,
        Type
        } from '@angular/core';

@Component({
    selector:'app-widget-loader',
    template:`<div #content></div>`,
    styleUrls:[]
})
export class WidgetLoader implements OnInit, OnDestroy{
 @ViewChild('content', {read: ViewContainerRef})
 content: ViewContainerRef;

 @Input() selector:string;
 @Input() settings:string;

 private componentRef: ComponentRef<any>;

    constructor(private cfr:ComponentFactoryResolver,
                private sidebarService:SidebarService){

    }

    ngOnInit(){
    const type = this.sidebarService.widgets[this.selector];
    if (type) {
      const factory = this.cfr.resolveComponentFactory(type);

      this.content.clear();
      this.componentRef = this.content.createComponent(factory, 0);
     }
    }

    ngOnDestroy(){
        if(this.componentRef)
        {
            this.componentRef.destroy();
            this.componentRef = null;
        }
    }

}