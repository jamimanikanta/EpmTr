import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AuthGaurd } from './services/authguard.service';
import { LoginComponent } from './login/login.component';
import { FeatureTogglingComponent } from './admin/feature-toggling/feature-toggling.component';


const routes:Routes = [
    {path:'',redirectTo:'login', pathMatch:'full'},
    {path:'login',component: LoginComponent},
    { path: 'convictions', loadChildren: './convictions/conviction.module#ConvictionModule', canActivate: [AuthGaurd] },
    { path: 'admin', component: FeatureTogglingComponent , canActivate: [AuthGaurd] },
   ]

@NgModule({
    imports: [RouterModule.forRoot(routes,{useHash:true})],
    exports: [RouterModule]
})
export class AppRoutingModule {}