import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from "@angular/router";
import { AppComponent } from './app.component';
import { HeaderNavigationComponent } from "./header-navigation/header-navigation.component";
import { LoadingModule } from "ngx-loading";
import { NgProgressModule} from "ngx-progressbar";
import { MaterialModule } from "./material.module";
import { PersistanceService } from "./shared/persistance.service";
import { TranslateModule, TranslateService, TranslateLoader } from "@ngx-translate/core";
import {HttpLoaderFactory} from "./app.module";
import {HttpClientModule, HttpClient} from "@angular/common/http";
import { StoreModule, Store } from "@ngrx/store";
import { ConvictionReducer } from "./store/reducers/conviction.reducers";
describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        HeaderNavigationComponent
      ],
      imports:[HttpClientModule, RouterTestingModule, RouterModule, LoadingModule, NgProgressModule, MaterialModule, StoreModule.forRoot({
        convictions: ConvictionReducer
      }), TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [HttpClient]
        }
      })],
      providers:[PersistanceService, TranslateService, Store]
    }).compileComponents();
  }));
  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
