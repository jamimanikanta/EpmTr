import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Feature } from "../../model/session.model";
import { Observable } from "../../../../node_modules/rxjs";

@Injectable()
export class FeatureTogglingService{
    constructor(private http:HttpClient){
    }
    
    getFeatures(userName:string):Observable<Feature[]>{
        return this.http.get('../../assets/data/features.json').map(data=><Feature[]>data);
    }
}