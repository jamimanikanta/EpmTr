import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { FeatureTogglingComponent } from './feature-toggling.component';
import { MatListModule, MatSlideToggleModule} from "@angular/material";
import { FeatureTogglingService } from './feature-toggling.service';
import { HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';

describe('FeatureTogglingComponent', () => {
  let component: FeatureTogglingComponent;
  let fixture: ComponentFixture<FeatureTogglingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeatureTogglingComponent ],
      imports: [ MatListModule, MatSlideToggleModule, HttpClientModule ],
      providers: [FeatureTogglingService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeatureTogglingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit', inject([FeatureTogglingService], (service: FeatureTogglingService) => {
         let spy = spyOn(service, "getFeatures").and.returnValue(Observable.of(1));
         component.ngOnInit();
         expect(spy).toHaveBeenCalled();    
  }));
});
