import { TestBed, inject } from '@angular/core/testing';
import { FeatureTogglingService } from './feature-toggling.service';
import { HttpClientModule } from '@angular/common/http';

describe('FeatureTogglingService', () => {
    let features = {
        "Token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
     };
  beforeEach(() => {
    TestBed.configureTestingModule({
        imports: [HttpClientModule],
        providers: [FeatureTogglingService]  
    });
  });

  it('should be created', inject([FeatureTogglingService], (service: FeatureTogglingService) => {     
    service.getFeatures("").subscribe((data: any) => {
            expect(data.Token).toEqual(features.Token);
    })
  }));
});