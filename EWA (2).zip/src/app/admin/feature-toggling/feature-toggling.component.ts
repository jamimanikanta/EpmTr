import { Component, OnInit } from '@angular/core';
import { FeatureTogglingService } from './feature-toggling.service';
import { Feature } from '../../model/session.model';

@Component({
  selector: 'app-feature-toggling',
  templateUrl: './feature-toggling.component.html',
  styleUrls: ['./feature-toggling.component.css']
})
export class FeatureTogglingComponent implements OnInit {
  features:Feature[];
  constructor(private featureTogglingService:FeatureTogglingService) { }

  ngOnInit() {
    this.featureTogglingService.getFeatures('').subscribe((data)=>this.features=data);
  }
}
