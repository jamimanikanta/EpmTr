import { environment } from "../../environments/environment.prod";

export const urls = {
    filters:environment.baseUrl+"filters",
    convictions:environment.baseUrl+"convictions",
    fileUpload:environment.baseUrl+ "fileprocess"

}