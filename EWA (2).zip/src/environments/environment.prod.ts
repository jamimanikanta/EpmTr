export const environment = {
  production:true,
  baseUrl : "http://ec2-54-213-65-232.us-west-2.compute.amazonaws.com/api/api/",
  stockApiUrl:"https://api.iextrading.com/1.0/stock/{0}/quote",
  PLAN_ID : "",
  API_KEY: ""
};




