# NorQuote
NorQuote Implementation
