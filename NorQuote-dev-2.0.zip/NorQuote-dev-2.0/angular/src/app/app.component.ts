import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {trigger, state, style, transition, animate} from '@angular/animations';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  index: number = 0;
  menuActive: boolean;
  activeMenuId: string;

  notification: boolean = false;

  constructor(private router: Router) {
  }
}
//   handleChange(e) {
//     let index = e.index;
//     let link;
//     switch (index) {
//       case 0:
//         link = ['/home'];
//         break;
//       case 1:
//         link = ['/office'];
//         break;
//       case 2:
//         link = ['/shop'];
//         break;
//     }
//     this.router.navigate(link);
//   }
//
//   openNext() {
//     this.index = (this.index === 2) ? 0 : this.index + 1;
//   }
//
//   openPrev() {
//     this.index = (this.index === 0) ? 2 : this.index - 1;
//   }
//
//   onMenuButtonClick(event: Event) {
//     this.menuActive = !this.menuActive;
//     event.preventDefault();
//   }
// }
