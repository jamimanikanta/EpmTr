import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { AuthService } from '../../shared/services/auth.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent implements OnInit {
  isLoggedIn$: Observable<boolean>;
  title: string = '';
  adminmenu: boolean = false;
  servinglocal: boolean = false;
  constructor(private authService: AuthService, private router: Router, private activatedrouter: ActivatedRoute) {
  }

  ngOnInit() {
    if (environment.servinglocal) {
      this.isLoggedIn$ = new BehaviorSubject<boolean>(true);
    } else {
      this.isLoggedIn$ = this.authService.isLoggedIn; // {2}
    }

    this.authService.pageTitle().subscribe((event) => this.title = event['title']);
  }

  onLogout() {
    this.router.navigate(['/login']);
    this.authService.logout();                      // {3}
  }
  jobDetails() {
    this.router.navigate(['/job-details']);
  }

  createJob() {
    this.router.navigate(['/create-job']);
  }

  createExecution() {
    this.router.navigate(['/job-execution']);
  }

  dashboard() {
    this.router.navigate(['/dashboard']);
  }
}
