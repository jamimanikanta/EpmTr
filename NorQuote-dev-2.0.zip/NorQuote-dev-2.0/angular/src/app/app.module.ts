import { NgModule , CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {HttpClientModule} from '@angular/common/http';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatSnackBarModule} from "@angular/material";

import { TreeModule } from 'ng2-tree';

import { MyOwnCustomMaterialModule } from './shared/material.module';

import { AppComponent } from './app.component';
import { ROUTING } from './app.routes';
//import {CalendarModule, DropdownModule, DataTableModule, InputTextModule, DialogModule,AccordionModule} from 'primeng/primeng';
//import {TableModule} from 'primeng/table';

//import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { LoginComponent } from './modules/login/login.component';
// import { Http, RequestOptions, Headers } from '@angular/http';
import { HeaderComponent } from './core/header/header.component';
import { FooterComponent } from './core/footer/footer.component';


import { AuthService } from './shared/services/auth.service';
import { AuthGuard } from './shared/guards/auth.guard';
import { CommonService } from './shared/services/common.service';
import { ClickStopPropagation } from './shared/directives/stopClick';
import { TableFilterPipe } from './shared/pipes/tablefilterpipe';
import { OrderByPipe } from './shared/pipes/sorting';
import { dateFormattedPipe } from './shared/pipes/dateformat';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { LeftnavComponent } from './core/leftnav/leftnav.component';
import { BomComponent } from './modules/dashboard/bom/bom.component';
import { NewbomComponent } from './modules/dashboard/bom/newbom/newbom.component';
import { QuotesComponent } from './modules/dashboard/quotes/quotes.component';
import { RfqComponent } from './modules/dashboard/rfq/rfq.component';
import { LaborComponent } from './modules/dashboard/labor/labor.component';
import { RfqdetailsComponent } from './modules/dashboard/rfq/rfqdetails/rfqdetails.component';
import { ConfirmDialogComponent } from './modules/dashboard/confirm-dialog/confirm-dialog.component';
import { LabourdetailsComponent } from './modules/dashboard/bom/labourdetails/labourdetails.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    ClickStopPropagation,
    TableFilterPipe, 
    OrderByPipe,dateFormattedPipe, 
    DashboardComponent, 
    LeftnavComponent, 
    BomComponent, 
    NewbomComponent, 
    QuotesComponent, 
    RfqComponent, 
    LaborComponent,
    RfqdetailsComponent,
    ConfirmDialogComponent,
    LabourdetailsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MyOwnCustomMaterialModule,
    //CalendarModule, DropdownModule, DataTableModule, InputTextModule, DialogModule,TableModule,AccordionModule,
    FormsModule,
    ReactiveFormsModule,
    ROUTING,
    TreeModule,
    MatGridListModule,
    MatSnackBarModule
    //NgbModule.forRoot()
  ],
  entryComponents: [NewbomComponent, RfqdetailsComponent, ConfirmDialogComponent,LabourdetailsComponent],
  providers: [AuthService, AuthGuard,CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
