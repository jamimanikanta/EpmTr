import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './modules/login/login.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';

import { AuthGuard } from './shared/guards/auth.guard';

export const ROUTES: Routes = [
  {path: '', redirectTo: 'dashboard', pathMatch: 'full'},
  {path: 'login', component: LoginComponent},
//  {path: 'job-details', component: JobDetailsComponent, canActivate: [AuthGuard], data: { title: 'Job details' }},
  //{path: 'create-job', component: CreateJobComponent, canActivate: [AuthGuard], data: { title: 'Create New Job' }},
  //{path: 'job-execution', component: JobExecutionNschedulingComponent, canActivate: [AuthGuard], data: { title: 'Job Execution' }},
  {path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard], data: { title: 'Dashboard' }}
];

export const ROUTING: ModuleWithProviders = RouterModule.forRoot(ROUTES);
