import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'tablefilterpipe',
    pure: false
})
export class TableFilterPipe implements PipeTransform {
    transform(items: any[], filter: String): any {
        if (!items || !filter) {
            return items;
        }
        return items.filter(function (itm) {
            let ret = false;
            for (let key in itm) {
                if (!ret) {
                    ret = itm[key] ? itm[key].toString().toLowerCase().includes(filter.toLowerCase()) : false;
                }
            }
            return ret;
        });
    }
}