import { NgModule} from '@angular/core';

import {MatFormFieldModule, MatInputModule , MatButtonModule, MatPaginatorModule, MatCheckboxModule,MatTooltipModule,TooltipPosition, MatTableModule, MatPaginator, MatSort, MatTableDataSource,MatDialogModule, MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatDatepickerModule,MatNativeDateModule,MatProgressSpinnerModule,MatSortModule,MatSelectModule,MatButtonToggleModule,MatRadioModule} from '@angular/material';


const materialArray = [MatFormFieldModule, MatInputModule , MatPaginatorModule, MatButtonModule, MatCheckboxModule,MatTooltipModule,MatTableModule,MatDialogModule,MatDatepickerModule,MatProgressSpinnerModule,MatNativeDateModule,MatSortModule,MatSelectModule,MatButtonToggleModule,MatRadioModule];

@NgModule({
  imports: [materialArray],
  exports: [materialArray],
})
export class MyOwnCustomMaterialModule { }