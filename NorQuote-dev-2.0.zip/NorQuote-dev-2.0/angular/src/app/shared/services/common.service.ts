import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import {environment} from '../../../environments/environment';

@Injectable()
export class CommonService {
     apiurl: string = environment.apiurl;
     localUrl: string = 'assets/data/dashboard.json';
     laborDetailsURL : string = 'assets/data/labourdetails.json';

    constructor(
        private router: Router,
        private http: HttpClient
    ) { }

    dashboardJobStatus(): Observable<any> {
        // this.apiurl + 'job'
        // 'assets/data/dashboard.json'
        var url = environment.servinglocal ? 'assets/data/dashboard.json' : `${this.apiurl}bom/all`;
        return this.http.get(url)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err.statusText);
        });
    }

    fileUpload(file): Observable<any> {
        return this.http.post(`${this.apiurl}bom/upload`, file)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err);
        });
    }

    dashboardRFQJobStatus(): Observable<any> {
        var url = environment.servinglocal ? 'assets/data/dashboard.json' : `${this.apiurl}rfq/allRfqs`;
        return this.http.get(url)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err.statusText);
        });
    }
    createRFQ(bomID): Observable<any> {
        var url = `${this.apiurl}rfq/create/${bomID}`;
        return this.http.get(url)
            .map((res: Response) => {return res;})
            .catch((err: Error | any) => {
                return Observable.throw(err);
        });
    }
    deleteBOM(bomID): Observable<any> {
        var url = `${this.apiurl}bom/delete/${bomID}`;
        return this.http.get(url)
            .map((res: Response) => {return res;})
            .catch((err: Error | any) => {
                return Observable.throw(err);
        });
    }
    rfqcontrolsload(): Observable<any> {
      //  var url = environment.servinglocal ? 'assets/data/rfq/rfqconfload.json' : `${this.apiurl}rfq/allRfqs`;
        var url = 'assets/data/rfq/rfqconfload.json';
        return this.http.get(url)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err.statusText);
        });
    }

    rfqconsolidationtableheaders(): Observable<any> {
      //  var url = environment.servinglocal ? 'assets/data/rfq/rfqconfload.json' : `${this.apiurl}rfq/allRfqs`;
        var url = 'assets/data/rfq/rfqconfsavetableheader.json';
        return this.http.get(url)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err.statusText);
        });
    }

    rfqconsolidationtabledata(): Observable<any> {
      //  var url = environment.servinglocal ? 'assets/data/rfq/rfqconfload.json' : `${this.apiurl}rfq/allRfqs`;
        var url = 'assets/data/rfq/rfqconfsavetabledata.json';
        return this.http.get(url)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err.statusText);
        });
    }


    quotesData(): Observable<any> {
        return this.http.get(this.localUrl)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err.statusText);
        });
    }

    laborData(): Observable<any> {
        return this.http.get(this.localUrl)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err.statusText);
        });
    }

    laborDetailsData(): Observable<any> {
        return this.http.get(this.laborDetailsURL)                  
            .map((res: Response) => { return res; })
            .catch((err: Response | any) => {
                return Observable.throw(err.statusText);
        });
    }

}