export interface jobDetails {
  fundName?: string;
  EDARP?: string;
  houseHold?: string;
  PDARP?: string;
  TRAC?: string;
  editEnable?:boolean;
}
