import { Component, OnInit } from '@angular/core';

import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
//import { CalendarModule, DropdownModule, DataTableModule, InputTextModule, DialogModule, AccordionModule } from 'primeng/primeng';
import { Router } from '@angular/router';
//import { TableModule } from 'primeng/table';
//import { SelectItem, SelectItemGroup } from 'primeng/api';
import { CommonService } from '../../shared/services/common.service';
import { TreeModel } from 'ng2-tree';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  dashboardjobrecords: any = [];

  constructor(private dashboardComponentService: CommonService) { }
  public tree: TreeModel = {
    value: '',
    children: [
      {
        value: 'bom'
      },
      {
        value: 'rfq'
      },
      {
        value: 'quotes'
      }, {
        value: 'labor'
      }
    ]
  };
  ngOnInit() {
    //this.dashboardTable();
  }
  test(){
    alert('sdfsfd')
  }
  
  

  /*dashboardTable() {
    this.dashboardComponentService.dashboardJobStatus().subscribe(
      data => {
        this.dashboardjobrecords = data; // [...r];
      }
    );
  }*/






}
