import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';

import { BehaviorSubject } from "rxjs";
import { CommonService } from '../../../shared/services/common.service';
import { NewbomComponent } from './newbom/newbom.component';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { LabourdetailsComponent } from './labourdetails/labourdetails.component'

import { RfqComponent } from '../rfq/rfq.component';

@Component({
  selector: 'dashboard-bom',
  templateUrl: './bom.component.html',
  styleUrls: ['./bom.component.css']
})

export class BomComponent implements OnInit {
  bomColumns = ['duedate', 'submitted', 'customerName', 'location', 'salesperson', 'description', 'status', 'filename', 'project', 'actions'];
  dataSource: MatTableDataSource<any>;
  dataSourceRecords:any=[];
  toggleBOMSection: boolean = true;
  loader: boolean = false;
  rfqSpinner: boolean = false;
  bomID: String;
  index: number;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(RfqComponent) RfqComponent : RfqComponent;

  constructor(private service: CommonService, public dialog: MatDialog, public snackBar: MatSnackBar) { }

  ngOnInit() {
    //this.dataSource.paginator = this.paginator;
    //this.dataSource.sort = this.sort;
    this.bomTable();
  }

  toggleBOM() {
    this.toggleBOMSection = !this.toggleBOMSection
  }

  newBOM(): void {
    let dialogRef = this.dialog.open(NewbomComponent, {
      width: '600px',
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
        this.addRecordToBOMTable(result);
      }
    });

  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  addRecordToBOMTable(record){
    const data = this.dataSource.data;
    data.unshift(record);
    this.dataSource.data = data;
  }

  bomTable() {
    this.loader = true;
    this.service.dashboardJobStatus().subscribe(
      data => {
        this.loader = false;
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSourceRecords = data;
      }, err => {
        this.loader = false;
      }
    );
  }

  RFQDialog(bomID): void {
    this.bomID = bomID;
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        bomId: bomID,
        title: 'Create RFQ',
        text: 'Are you sure you want to create RFQ for this BOM ?'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result && result.action === 'yes'){
        this.createRfq(result.bomId);
      }
    });
  }

  labourDialog(bomID): void {
    this.bomID = bomID;
    const dialogRef = this.dialog.open(LabourdetailsComponent, {
      data: {
        bomId: bomID,
        title: 'Labour Details'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result && result.action === 'yes'){
        //this.createRfq(result.bomId);
      }
    });
  }


  deleteDialog(bomID, index): void {
    this.bomID = bomID;
    this.index = index;
    const deleteDialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        bomId: bomID,
        title: 'Delete BOM',
        text: 'Are you sure you want to delete this BOM ?'
      }
    });

    deleteDialogRef.afterClosed().subscribe(result => {
      if(result && result.action === 'yes'){
        this.deletebom(result.bomId);
      }
    });
  }


  createRfq(bomID) {
    this.rfqSpinner = true;
    this.service.createRFQ(bomID).subscribe(
      data => {
        this.bomTable();
        this.RfqComponent.RFQTable();
        this.rfqSpinner = false;
        this.openSnackBar('RFQ successfully created');
      }, err => {
        console.log(err);
        this.rfqSpinner = false;
        this.openSnackBar('Error while creating RFQ');
      }
    );
  }

  openSnackBar(message){
    this.snackBar.open(message, '', {
      verticalPosition: 'top',
      horizontalPosition: 'end',
      duration: 2000
    });
  }

  togglePlaceholder(){
    if(this.toggleBOMSection){
      return 'Collpase BOM';
    }else{
      return 'Expand BOM';
    }
  }

  deletebom(bomID){
    this.service.deleteBOM(bomID).subscribe(
      data => {
        // this.bomTable();
        this.dataSource.data.splice(this.index, 1);
        this.dataSource = new MatTableDataSource<Element>(this.dataSource.data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSourceRecords = this.dataSource;
        this.openSnackBar('BOM successfully deleted');
      }, err => {
        console.log(err);
        this.openSnackBar('Error while deleting file');
      }
    )
  }

}


/*
@Component({
  templateUrl: './newbom/newbom.component.html',
})
export class NewbomComponent {

  constructor(
    public dialogRef: MatDialogRef<NewbomComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

}*/
