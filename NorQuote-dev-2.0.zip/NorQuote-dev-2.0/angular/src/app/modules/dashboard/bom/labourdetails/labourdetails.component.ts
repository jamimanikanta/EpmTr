import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';

import { CommonService } from '../../../../shared/services/common.service';
import { Utils } from '../../../../shared/utils';

export interface DialogData {
  bomId: String;
  title: string;
  text: string;
  action: String;
}


@Component({
  selector: 'app-labourdetails',
  templateUrl: './labourdetails.component.html',
  styleUrls: ['./labourdetails.component.css']
})
export class LabourdetailsComponent implements OnInit {
labourSearchForm: FormGroup;

  dataToDisplay: any = [];
  columnsToDisplayGroup: any = [];
  columnsToDisplay = [];


  customersPartNamesList: any = [];
  customersPartNamesSelectedList: any = [];

  constructor(public dialogRef: MatDialogRef<LabourdetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,private service: CommonService) { }

  ngOnInit() {
    this.init();
  }
  init() {

    this.labourSearchForm = new FormGroup({
      customers: new FormControl(this.customersPartNamesSelectedList)
    });
    this.labourSearchForm.get('customers').valueChanges.subscribe(val => {
      this.tableHeader();
    });
    this.tableHeader();
  }

  tableHeader() {
    this.columnsToDisplayGroup = [];
    this.columnsToDisplay = [];
    this.columnsToDisplayGroup.push({ 'rowspan': 2, 'colspan': 0, 'data': 'Sequence' }, { 'rowspan': 2, 'colspan': 0, 'data': 'Operation' }, { 'rowspan': 2, 'colspan': 0, 'data': 'Lbr Std Hr' });
    this.tableBody();
  }

  customerpartrotate(val){
    val.forEach(custvalue => {
      this.columnsToDisplay.push('QTY', 'Hours');
      this.columnsToDisplayGroup.push({ 'rowspan': -1, 'colspan': 2, 'data': custvalue.name });
      
    });

  }

  tableBody(){
    this.service.laborDetailsData().subscribe(
      data => {
          this.dataToDisplay = data;
          this.customersPartNamesList = data[0].customers;
          this.customerpartrotate(this.customersPartNamesList);
          //this.customersList = data.map(item => item.age).filter((value, index, self) => self.indexOf(value) === index)

      });
  }

  closeDialog(action){
    this.data.action = action;
    this.dialogRef.close(this.data);
  }

}
