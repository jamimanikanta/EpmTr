import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabourdetailsComponent } from './labourdetails.component';

describe('LabourdetailsComponent', () => {
  let component: LabourdetailsComponent;
  let fixture: ComponentFixture<LabourdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabourdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabourdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
