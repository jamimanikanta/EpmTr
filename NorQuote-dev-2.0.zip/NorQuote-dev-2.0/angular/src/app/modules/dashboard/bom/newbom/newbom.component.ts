import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { CommonService } from '../../../../shared/services/common.service';
import { Utils } from '../../../../shared/utils';

@Component({
  selector: 'newbom',
  templateUrl: './newbom.component.html',
  styleUrls: ['./newbom.component.css']
})
export class NewbomComponent {
  newBOMForm: FormGroup;
  // testdata: string = 'sfsdsfsdf';
  minDate = new Date();
  fileuploaderrors: boolean = false;
  errorsInFile: any = [];
  fileValid: boolean = true;
  fileUploadLoader: boolean = false;
  file: any;
  @ViewChild('fileInput') fileInput;

  constructor(
    public dialogRef: MatDialogRef<NewbomComponent>,
    private service: CommonService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      dialogRef.disableClose = true;
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
    this.initCreateBOM();
  }

  initCreateBOM() {
    this.newBOMForm = new FormGroup({
      date: new FormControl("", Validators.required),
      file: new FormControl("", Validators.required)
    });
  }

  downaloaderror() {
    var content = document.getElementById('errors').innerText;
    /*// a [save as] dialog will be shown
    window.open("data:application/txt," + encodeURIComponent(content), "_self");*/
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', 'Error.txt');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }
  
  onFileChange(evt){
    this.fileuploaderrors = false;
    this.fileValid = true;
    this.file = evt.target.files[0];
    if(this.file){
      const fileExt = this.file.name.split('.').pop();
      if(fileExt !== 'xls' && fileExt !== 'xlsx'){
        this.fileValid = false;
      }
    }
  }

  submitForm() {
    if(!this.newBOMForm.value.file){
      this.fileValid = false;
    }
    if(this.newBOMForm.valid){
      this.fileUploadLoader = true;
      const formData = new FormData();
      formData.append('dueDate', Utils.dateFormat(this.newBOMForm.value.date));
      formData.append('file', this.fileInput.nativeElement.files[0]);
      this.service.fileUpload(formData).subscribe(
        data => {
          //var data = {"error":false,"errors":["tessss"],"duedate":"06/12/2018"}
          this.fileUploadLoader = false;
          this.dialogRef.close(data);
        }, (err) => {
          this.fileUploadLoader = false;
          if(err.error.error === true){
            const data = err.error;
            if (data.errors && data.errors.length > 0) {
              this.fileuploaderrors = true;
              this.errorsInFile = data.errors;
            }
          }
        }
      );
      }
    }
  }
