import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from '../../../shared/services/common.service';

@Component({
  selector: 'dashboard-labor',
  templateUrl: './labor.component.html',
  styleUrls: ['./labor.component.css']
})
export class LaborComponent implements OnInit {
  toggleLaborSection:boolean = false
  
  columnsToDisplay = ['dueDate', 'ID', 'customer', 'createdDate', 'market', 'product', 'nortechSite', 'crimpTooling', 'WandClabor', 'EMSTooling', 'EMSLabor', 'totalHours', 'totalEfforts' ];
  dataSource: MatTableDataSource<any>;
  dataSourceRecords:any=[];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit(){
    this.laborTable();
  }

  constructor(private service: CommonService) { }


  toggleLabor() {
    this.toggleLaborSection = !this.toggleLaborSection
  }


  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  laborTable() {
    this.service.laborData().subscribe(
      data => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSourceRecords = data;
      }
    );
  }

}
