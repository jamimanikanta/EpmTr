import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from '../../../shared/services/common.service';

@Component({
  selector: 'dashboard-quotes',
  templateUrl: './quotes.component.html',
  styleUrls: ['./quotes.component.css']
})
export class QuotesComponent implements OnInit {

  toggleQuotesSection: boolean = false;
  columnsToDisplay = ['date', 'ID', 'name', 'salesPerson', 'description', 'quoteGenerated', 'value', 'suppliers'];
  dataSource: MatTableDataSource<any>;
  dataSourceRecords:any=[];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit(){
    this.quotesTable();
  }

  constructor(private service: CommonService) { }

  toggleQuotes() {
    this.toggleQuotesSection = !this.toggleQuotesSection
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  quotesTable() {
    this.service.quotesData().subscribe(
      data => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSourceRecords = data;
      }
    );
  }
}
