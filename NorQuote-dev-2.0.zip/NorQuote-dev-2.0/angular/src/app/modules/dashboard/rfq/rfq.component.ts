import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from '../../../shared/services/common.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { RfqdetailsComponent } from './rfqdetails/rfqdetails.component';


@Component({
  selector: 'dashboard-rfq',
  templateUrl: './rfq.component.html',
  styleUrls: ['./rfq.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0', display: 'none'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ])
  ]
})
export class RfqComponent implements OnInit {
  toggleRFQSection: boolean = true;
  columnsToDisplay = ['action', 'createDate', 'ID', 'customer', 'salesPerson', 'description', 'rfqReceived', 'rfqPending', 'dueDate', 'partReceived', 'partPending'];
  supplierColumns = ['suppName', 'partsSent', 'partsQuoted', 'remindersSent', 'lastReminder', 'contact']
  dataSource: MatTableDataSource<any>;
  subDataSource: MatTableDataSource<any>;
  dataSourceRecords: any = [];
  subDataSourceRecords: any = [];
  expandedElement: any;
  rfqloader: boolean = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('tabSort') tabSort: MatSort;
  @ViewChild('subSort') subSort: MatSort;
  constructor(private service: CommonService, public dialog: MatDialog) { }

  ngOnInit() {
    this.RFQTable();
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  toggleRFQ() {
    this.toggleRFQSection = !this.toggleRFQSection;
  }
  getrfqdetailsdata(rowData) {
     let dialogRef = this.dialog.open(RfqdetailsComponent, {
      width: '98%',
      data: { name: 'testname', animal: 'testanimal' }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed'+result);
      if(result){
       
      }
    });
   
  }
  RFQTable() {
    this.rfqloader = true;
    this.service.dashboardRFQJobStatus().subscribe(
      data => {       
        this.rfqloader = false; 
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.tabSort;
        this.dataSourceRecords = data;        
      }, err => {
        this.rfqloader = false;
      }
    );
  }

  getSupplierDetails(row){
    if(this.expandedElement !== row){
      this.expandedElement = row;
    }else{
      this.expandedElement = {};
    }
    this.subDataSource = new MatTableDataSource(row.supplierDetails);
    this.subDataSource.sort = this.subSort;
    this.subDataSourceRecords = row.supplierDetails || [];
  }
}