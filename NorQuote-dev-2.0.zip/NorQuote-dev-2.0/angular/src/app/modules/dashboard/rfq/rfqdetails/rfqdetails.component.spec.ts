import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RfqdetailsComponent } from './rfqdetails.component';

describe('RfqdetailsComponent', () => {
  let component: RfqdetailsComponent;
  let fixture: ComponentFixture<RfqdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RfqdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RfqdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
