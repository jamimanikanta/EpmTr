import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSelectModule, MatButtonToggleModule, MatCheckboxModule, MatRadioModule } from '@angular/material';
import { CommonService } from '../../../../shared/services/common.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { Utils } from '../../../../shared/utils';


@Component({
  selector: 'app-rfqdetails',
  templateUrl: './rfqdetails.component.html',
  styleUrls: ['./rfqdetails.component.scss'],
  animations: [
    trigger('rfqcondetailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ])
  ]
})
export class RfqdetailsComponent implements OnInit {

  quoteControlValue: string = '';
  displayControlValue: any = [];
  quoteControlSeggroupValue: string = '';
  displayquoteQuantities: any = [];
  //columnsToDisplayHeaders = ['header1', '', '', 'header2', '', '', 'header3', '', '', '']


  dataToDisplay: any = [];
  columnsToDisplayGroup: any = [];
  columnsToDisplay: any = [];


  dataSource: MatTableDataSource<any>;
  dataSourceRecords: any = [];
  //selectionControl: string;
  controlsData: any = { "displayControl": [], "quoteControl": [] };
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  constructor(public dialogRef: MatDialogRef<RfqdetailsComponent>,
    private service: CommonService,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder) { }

  initCreate() {
    /*this.rfqDetailsForm = this.fb.group({
      displayControl: [true, [Validators.required]],
      selectionControl: ["", [Validators.required]]
    });*/
  }

  ngOnInit() {
    // this.initCreate();
    this.controls();
  }
  controls() {
    this.service.rfqcontrolsload().subscribe(
      data => {
        this.controlsData = data;
        this.quoteControlValue = data.quoteControl[0].label;
        this.displayControlValue = [data.displayControl[0].label];
        this.displayquoteQuantities = [1];
        this.tableHeaders();
      }
    );
  }

  tableHeaders() {
    this.columnsToDisplayGroup = [];
    this.columnsToDisplay = [];
    this.displayquoteQuantities = [];
    var regex = /\d+/;
    this.service.rfqconsolidationtableheaders().subscribe(
      data => {
        this.columnsToDisplayGroup.push({ 'rowspan': 2, 'colspan': 0, 'data': 'CPN' }, 
                                  { 'rowspan': 2, 'colspan': 0, 'data': 'Stock' }, 
                                  { 'rowspan': 2, 'colspan': 0, 'data': 'LT(WKS)' },
                                  { 'rowspan': 2, 'colspan': 0, 'data': 'Manufacturer' },
                                  { 'rowspan': 2, 'colspan': 0, 'data': 'Supplier' });
                                  
        this.columnsToDisplay.push({ 'rowspan': 2, 'colspan': 0, 'data': 'Supplier Name'}, 
                              { 'rowspan': 2, 'colspan': 0, 'data': 'Price'}, 
                              { 'rowspan': 2, 'colspan': 0, 'data': 'Excess cost' },
                              { 'rowspan': 2, 'colspan': 0, 'data': 'Extended Unit Price' },
                              { 'rowspan': 2, 'colspan': 0, 'data': 'Extended Value Price' },
                              { 'rowspan': 2, 'colspan': 0, 'data': 'More Details'});
        this.displayControlValue.forEach(datadcv => {
          this.columnsToDisplayGroup.push({ 'rowspan': -1, 'colspan': 6, 'data': datadcv });
          this.displayquoteQuantities.push(datadcv.match(regex)-1);
        });

        if (this.displayControlValue.length == 0 && this.quoteControlValue.length !== 0) {
          // this.columnsToDisplayGroup.push({ 'rowspan': -1, 'colspan': 5, 'data': this.quoteControlValue });
          this.columnsToDisplay = this.columnsToDisplay.concat(data.columQuantities[0].colums);
          var n:any = this.quoteControlValue.match(regex);
          this.displayquoteQuantities.push(n-1);
        }

        this.tableBody();



      }
    );

    // this.tableBody();
  }

  tableBody() {
    this.service.rfqconsolidationtabledata().subscribe(
      data => {
        let d = data;
        d.forEach(dataObject => {
          let newColumQuantities = [];
          this.displayquoteQuantities.forEach(num => {
            newColumQuantities.push(dataObject.columQuantities[num])
          });
          dataObject.columQuantities = newColumQuantities;
        });
        this.dataToDisplay = d;
      }
    );
  }

  expandRow(data) {
    data.datarowdisplay = !data.datarowdisplay;
  }

  displaycontrol(objSel) {
    let x = [];
    this.controlsData.displayControl.forEach(dc => {
      if (dc.value) {
        x.push(dc.label)
      }
    });
    this.displayControlValue = x;
    this.quoteControlValue = '';
    this.quoteControlSeggroupValue = '';
    this.tableHeaders();
  }

  quotecontrol(val) {
    //alert(val);
    this.controlsData.displayControl.forEach(dc => {
      dc.value = false;
    });
    this.quoteControlValue = val;
    this.displayControlValue = [];
    if (this.quoteControlSeggroupValue.length == 0) {
      this.quoteControlSeggroupValue = 'Manual';
    }
    this.tableHeaders();
    // alert(this.quoteControlValue)

  }

  quotecontrolCQM(val) {
    this.controlsData.displayControl.forEach(dc => {
      dc.value = false;
    });
    this.quoteControlSeggroupValue = val;
    this.displayControlValue = [];
    

  }

  onNoClick(): void {
    this.dialogRef.close();
  }


  RFQdetailsTable() {
    this.service.quotesData().subscribe(
      data => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSourceRecords = data;
      }
    );
  }

}
