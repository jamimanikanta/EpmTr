import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl} from '@angular/forms';
import {Router} from "@angular/router";
import { AuthService } from '../../shared/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [ FormBuilder ]
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  mockUsername:string;
  mockPassword:string;
  constructor(private fb: FormBuilder, private router: Router,
    private authService: AuthService) {
    this.mockUsername ="sai";
    this.mockPassword = "1234";
  }

  ngOnInit() {
    this.initLoginForm();
  }

  initLoginForm() {
    this.loginForm = new FormGroup({
      userName: new FormControl("", Validators.required),
      password: new FormControl("", Validators.required)
    });
  }

  signin(){
    this.authService.login(this.loginForm.value);
    //this.router.navigate(['/job-details'])
  }
  /*getLoginCredentials(credentials){
    if(credentials.userName === this.mockUsername && credentials.password === this.mockPassword){
      this.router.navigate(['/jcl-utility'])
    }
  }*/
}
