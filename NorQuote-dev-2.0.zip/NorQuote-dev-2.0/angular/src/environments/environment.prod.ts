export const environment = {
  production: true,
  servinglocal:false,  
  apiurl:"/"
};
